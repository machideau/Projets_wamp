from fpdf import FPDF

# Cahier des charges text
cahier_texte = """
Cahier des charges – Application Web de Gestion de Bulletins Scolaires

🎯 Objectif général
Développer une application web complète pour une école, permettant aux enseignants et aux administrateurs de :
- gérer les élèves et leurs matières,
- remplir, modifier et consulter les bulletins de notes,
- filtrer et générer les bulletins en PDF ou version imprimable,
- disposer d'une interface moderne avec des couleurs violettes en dégradé.

⚙️ Technologies imposées
- Backend : Python Flask
- Frontend : HTML, CSS (style personnalisé + Tailwind ou Bootstrap autorisé), JavaScript
- Base de données : SQLite (via SQLAlchemy)
- PDF : WeasyPrint (ou équivalent)

🧱 Structure du projet (obligatoire)
L’IA doit générer le projet dans cette structure précise :
bulletin_scolaire/
├── app/
│   ├── __init__.py
│   ├── models.py
│   ├── routes/
│   │   ├── auth_routes.py
│   │   ├── eleve_routes.py
│   │   ├── matiere_routes.py
│   │   ├── note_routes.py
│   │   ├── bulletin_routes.py
│   │   └── historique_routes.py
│   ├── templates/
│   │   ├── auth/
│   │   ├── eleves/
│   │   ├── notes/
│   │   ├── bulletins/
│   │   ├── historique/
│   │   └── layout.html
│   └── static/
│       ├── css/
│       ├── js/
│       └── images/
├── database/
├── migrations/
├── tests/
├── .env
├── config.py
├── requirements.txt
├── run.py
└── README.md

👤 Authentification
- Inscription et connexion sécurisées avec mot de passe hashé (admin et enseignants)
- Middleware pour protéger les pages nécessitant une connexion

👥 Gestion des élèves et matières
- CRUD complet pour :
  - Élèves (nom, prénom, classe, etc.)
  - Matières (nom, coefficient)

✍️ Remplissage et édition des notes
- Interface permettant de saisir les notes des élèves par matière
- Modification possible des notes
- Validation avant enregistrement

📄 Génération et consultation des bulletins
- Génération de bulletins de notes (moyenne générale, notes par matière, mention si possible)
- Deux options :
  - Affichage HTML stylisé
  - Téléchargement en PDF
- Historique des bulletins par élève

🔎 Filtres intelligents
- Filtres dynamiques côté JavaScript :
  - par classe
  - par nom d’élève
  - par moyenne (ex. > 10)

🎨 Interface utilisateur
- Design moderne, responsive
- Thème principal : violet dégradé avec nuances claires pour la lisibilité
- Utiliser une police élégante
- Menu de navigation sticky en haut
- Boutons arrondis, ombrés
- Modales pour les formulaires (bonus)

✅ Tests
- Tests unitaires sur les routes principales :
  - Connexion
  - Création d’élève
  - Saisie de note
  - Génération de bulletin

📦 Dépendances à inclure (requirements.txt)
Flask
Flask-Login
Flask-WTF
Flask-SQLAlchemy
python-dotenv
WeasyPrint

💬 Bonus si possible
- Message flash de confirmation ou d’erreur
- Pagination sur les longues listes
- Affichage dynamique des moyennes dès la saisie

🧠 Résultat attendu
L’agent IA doit générer tout le code dans cette structure, prêt à exécuter avec run.py, et avec une interface élégante en violet dégradé. Le projet doit être entièrement fonctionnel localement.
"""

# Create PDF
pdf = FPDF()
pdf.add_page()
pdf.set_auto_page_break(auto=True, margin=15)
pdf.set_font("Arial", size=12)
for line in cahier_texte.split('\n'):
    pdf.multi_cell(0, 10, line)

# Save the PDF
pdf_path = "Cahier_des_charges_site_ecole.pdf"
pdf.output(pdf_path)

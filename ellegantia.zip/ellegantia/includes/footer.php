<?php
$categories = getAllCategories();
?>
<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-4">
                <h3>Ellegantia Shoes</h3>
                <p>Votre destination pour des chaussures élégantes et confortables.</p>
                <div class="social-icons">
                    <a href="#"><i class="fa fa-facebook"></i></a>
                    <a href="#"><i class="fa fa-instagram"></i></a>
                    <a href="#"><i class="fa fa-pinterest"></i></a>
                </div>
            </div>
            <div class="col-md-4">
                <h3>Liens Rapides</h3>
                <ul class="footer-links">
                    <li><a href="shop.php">Collection</a></li>
                    <li><a href="produits.php">Produits</a></li>
                    <li><a href="propos.php">À Propos</a></li>
                    <li><a href="contact.php">Contact</a></li>
                </ul>
                <h3>Catégories</h3>
                <ul class="footer-links">
                    <?php foreach ($categories as $category): ?>
                        <li><a href="produits.php?category=<?php echo htmlspecialchars($category['slug']); ?>"><?php echo htmlspecialchars($category['name']); ?></a></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-md-4">
                <h3>Contact</h3>
                <p><i class="fa fa-map-marker"></i> 123 Rue de la Mode, Paris</p>
                <p><i class="fa fa-phone"></i> +33 1 23 45 67 89</p>
                <p><i class="fa fa-envelope"></i> contact@ellegantia.com</p>
            </div>
        </div>
        <div class="copyright">
            <p>&copy; <?php echo date('Y'); ?> Ellegantia Shoes. Tous droits réservés.</p>
        </div>
    </div>
</footer> 
<?php
$currentPage = basename($_SERVER['PHP_SELF']);
$user = getCurrentUser();
?>
<header>
    <nav>
        <div class="logo-text">Ellegantia Shoes</div>
        <div class="hamburger">
            <i class="fa fa-bars"></i>
        </div>

        <div class="nav-links">
            <a href="index.php" <?php echo $currentPage === 'index.php' ? 'class="active"' : ''; ?>>Accueil</a>
            <a href="shop.php" <?php echo $currentPage === 'shop.php' ? 'class="active"' : ''; ?>>Collection</a>
            <a href="produits.php" <?php echo $currentPage === 'produits.php' ? 'class="active"' : ''; ?>>Produits</a>
            <a href="propos.php" <?php echo $currentPage === 'propos.php' ? 'class="active"' : ''; ?>>À Propos</a>
            <a href="contact.php" <?php echo $currentPage === 'contact.php' ? 'class="active"' : ''; ?>>Contact</a>
        </div>

        <div class="nav-right">
            <div class="cart-icon">
                <a href="panier.php" <?php echo $currentPage === 'panier.php' ? 'class="active"' : ''; ?>>
                    <i class="fa fa-shopping-cart"></i>
                    <?php if (!empty(getCart())): ?>
                        <span class="cart-count"><?php echo array_sum(getCart()); ?></span>
                    <?php endif; ?>
                </a>
            </div>
            <div class="auth-buttons">
                <?php if ($user): ?>
                    <div class="dropdown">
                        <button class="btn btn-secondary dropdown-toggle" type="button" id="userDropdown" data-bs-toggle="dropdown" aria-expanded="false">
                            <?php echo htmlspecialchars($user['username']); ?>
                        </button>
                        <ul class="dropdown-menu" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="profile.php">Mon Profil</a></li>
                            <li><a class="dropdown-item" href="orders.php">Mes Commandes</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Déconnexion</a></li>
                        </ul>
                    </div>
                <?php else: ?>
                    <button class="login-btn" onclick="window.location.href='login.php'">Connexion</button>
                    <button class="signup-btn" onclick="window.location.href='signup.php'">Inscription</button>
                <?php endif; ?>
            </div>
        </div>
    </nav>
</header> 
# Recommandations pour les images

## Tailles d'images recommandées

### Images de produits (dossier shoes/)
- Vignettes de produits: 600 x 600 pixels
- Images détaillées: 1200 x 1200 pixels
- Format: JPG ou PNG (avec fond transparent si nécessaire)
- Ratio: 1:1 (carré) pour une présentation uniforme

### Image d'arrière-plan (hero-bg.jpg)
- Taille: 1920 x 1080 pixels
- Format: JPG
- Ratio: 16:9

### Images de bannières
- Taille: 1920 x 500 pixels
- Format: JPG
- Ratio: environ 4:1

### Images de l'équipe (about page)
- Taille: 400 x 400 pixels
- Format: JPG ou PNG
- Ratio: 1:1 (carré)

### Logo
- Taille: 200 x 80 pixels
- Format: PNG avec transparence
- Résolution: haute pour éviter la pixellisation

## Optimisation des images
- Compresser toutes les images pour le web (utiliser des outils comme TinyPNG)
- Taille de fichier cible: moins de 200 KB pour les images de produits
- Utiliser des noms de fichiers descriptifs (ex: "bottine-cuir-noir.jpg")
- Ajouter des attributs alt descriptifs pour l'accessibilité et le SEO

## Structure des dossiers
- /img/shoes/ - Images de produits
- /img/banners/ - Bannières promotionnelles
- /img/team/ - Photos de l'équipe
- /img/logo/ - Logo et éléments de marque
document.addEventListener('DOMContentLoaded', function() {
    // Récupérer les éléments du DOM
    const cartItemsContainer = document.getElementById('cart-items');
    const cartSubtotal = document.getElementById('cart-subtotal');
    const shippingCost = document.getElementById('shipping-cost');
    const cartTotal = document.getElementById('cart-total');
    const clearCartBtn = document.getElementById('clear-cart');
    const checkoutBtn = document.getElementById('checkout-btn');
    const applyPromoBtn = document.getElementById('apply-promo');
    const promoCodeInput = document.getElementById('promo-code');
    const emptyCartMessage = document.querySelector('.empty-cart-message');
    
    // Récupérer les articles du panier depuis le localStorage
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    console.log(cartItems)
    
    // Afficher les articles du panier
    function displayCartItems() {
        // Vider le conteneur
        cartItemsContainer.innerHTML = '';
        
        if (cartItems.length === 0) {
            // Afficher le message de panier vide
            cartItemsContainer.appendChild(emptyCartMessage);
            clearCartBtn.style.display = 'none';
            return;
        } else {
            clearCartBtn.style.display = 'inline-block';
        }
        
        // Créer un élément pour chaque article
        cartItems.forEach((item, index) => {
            const cartItemElement = document.createElement('div');
            cartItemElement.className = 'cart-item';
            cartItemElement.innerHTML = `
                <div class="row align-items-center">
                    <div class="col-md-6">
                        <div class="product-info d-flex align-items-center">
                            <img src="img/shoes/shoes${item.id}.jpg" alt="${item.name}" class="cart-item-image">
                            <div>
                                <h4>${item.name}</h4>
                                <button class="remove-item" data-index="${index}">supprimer</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <div class="item-price">${item.price.toFixed(2)} €</div>
                    </div>
                    <div class="col-md-2">
                        <div class="quantity-controls">
                            <button class="quantity-btn decrease" data-index="${index}">-</button>
                            <span class="quantity">${item.quantity}</span>
                            <button class="quantity-btn increase" data-index="${index}">+</button>
                        </div>
                    </div>
                    <!-- <div class="col-md-2">
                        
                        <div class="item-total">${(item.price * item.quantity).toFixed(2)} €</div>
                    </div> -->
                </div>
            `;
            cartItemsContainer.appendChild(cartItemElement);
        });
        
        // Ajouter les écouteurs d'événements pour les boutons de quantité et de suppression
        addEventListeners();
        
        // Mettre à jour le récapitulatif
        updateCartSummary();
    }
    
    // Ajouter les écouteurs d'événements
    function addEventListeners() {
        // Boutons de suppression
        const removeButtons = document.querySelectorAll('.remove-item');
        removeButtons.forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(button.getAttribute('data-index'));
                removeItem(index);
            });
        });
        
        // Boutons de quantité
        const decreaseButtons = document.querySelectorAll('.quantity-btn.decrease');
        const increaseButtons = document.querySelectorAll('.quantity-btn.increase');
        
        decreaseButtons.forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(button.getAttribute('data-index'));
                decreaseQuantity(index);
            });
        });
        
        increaseButtons.forEach(button => {
            button.addEventListener('click', function() {
                const index = parseInt(button.getAttribute('data-index'));
                increaseQuantity(index);
            });
        });
    }
    
    // Supprimer un article
    function removeItem(index) {
        cartItems.splice(index, 1);
        saveCart();
        displayCartItems();
        updateCartCount();
    }
    
    // Diminuer la quantité
    function decreaseQuantity(index) {
        if (cartItems[index].quantity > 1) {
            cartItems[index].quantity -= 1;
        } else {
            removeItem(index);
            return;
        }
        saveCart();
        displayCartItems();
    }
    
    // Augmenter la quantité
    function increaseQuantity(index) {
        cartItems[index].quantity += 1;
        saveCart();
        displayCartItems();
    }
    
    // Mettre à jour le récapitulatif
    function updateCartSummary() {
        const subtotal = cartItems.reduce((total, item) => total + (item.price * item.quantity), 0);
        const shipping = subtotal > 0 ? 5.99 : 0;
        const total = subtotal + shipping;
        
        cartSubtotal.textContent = subtotal.toFixed(2) + ' €';
        shippingCost.textContent = shipping.toFixed(2) + ' €';
        cartTotal.textContent = total.toFixed(2) + ' €';
    }
    
    // Mettre à jour le compteur du panier
    function updateCartCount() {
        const cartCount = document.querySelector('.cart-count');
        if (cartCount) {
            cartCount.textContent = cartItems.length;
        }
    }
    
    // Sauvegarder le panier dans le localStorage
    function saveCart() {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
    }
    
    // Vider le panier
    function clearCart() {
        cartItems = [];
        saveCart();
        displayCartItems();
        updateCartCount();
    }
    
    // Appliquer un code promo
    function applyPromoCode() {
        const promoCode = promoCodeInput.value.trim().toUpperCase();
        
        // Exemple de codes promo
        const promoCodes = {
            'WELCOME10': 0.1,  // 10% de réduction
            'SUMMER20': 0.2,   // 20% de réduction
            'SHOES50': 0.5     // 50% de réduction
        };
        
        if (promoCodes[promoCode]) {
            const discount = promoCodes[promoCode];
            const subtotal = parseFloat(cartSubtotal.textContent);
            const discountAmount = subtotal * discount;
            const newTotal = subtotal - discountAmount + parseFloat(shippingCost.textContent);
            
            // Mettre à jour le total
            cartTotal.textContent = newTotal.toFixed(2) + ' €';
            
            // Ajouter un message de succès
            const successMessage = document.createElement('div');
            successMessage.className = 'promo-success';
            successMessage.textContent = `Code promo appliqué : -${(discount * 100)}%`;
            
            // Remplacer le message existant s'il y en a un
            const existingMessage = document.querySelector('.promo-success');
            if (existingMessage) {
                existingMessage.remove();
            }
            
            const existingError = document.querySelector('.promo-error');
            if (existingError) {
                existingError.remove();
            }
            
            promoCodeInput.parentNode.appendChild(successMessage);
        } else {
            // Afficher un message d'erreur
            const errorMessage = document.createElement('div');
            errorMessage.className = 'promo-error';
            errorMessage.textContent = 'Code promo invalide';
            
            // Remplacer le message existant s'il y en a un
            const existingError = document.querySelector('.promo-error');
            if (existingError) {
                existingError.remove();
            }
            
            const existingSuccess = document.querySelector('.promo-success');
            if (existingSuccess) {
                existingSuccess.remove();
            }
            
            promoCodeInput.parentNode.appendChild(errorMessage);
        }
    }
    
    // Procéder au paiement
    function checkout() {
        if (cartItems.length === 0) {
            alert('Votre panier est vide');
            return;
        }
        
        // Rediriger vers la page de paiement (à implémenter)
        alert('Redirection vers la page de paiement...');
        // window.location.href = 'checkout.html';
    }
    
    // Ajouter les écouteurs d'événements pour les boutons
    clearCartBtn.addEventListener('click', clearCart);
    checkoutBtn.addEventListener('click', checkout);
    applyPromoBtn.addEventListener('click', applyPromoCode);
    
    // Ajouter des écouteurs pour les boutons "Ajouter au panier" dans la section produits associés
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = button.getAttribute('data-product-id');
            const product = {
                id: productId,
                name: button.getAttribute('data-product-name'),
                price: parseFloat(button.getAttribute('data-product-price')),
                quantity: 1
            };
            
            // Vérifier si le produit existe déjà dans le panier
            const existingProductIndex = cartItems.findIndex(item => item.id === productId);
            
            if (existingProductIndex === -1) {
                cartItems.push(product);
            } else {
                cartItems[existingProductIndex].quantity += 1;
            }
            
            // Mettre à jour le localStorage
            saveCart();
            
            // Mettre à jour l'affichage
            displayCartItems();
            updateCartCount();
            
            // Afficher un message de confirmation
            const confirmMessage = document.createElement('div');
            confirmMessage.className = 'add-to-cart-confirmation';
            confirmMessage.textContent = 'Produit ajouté au panier !';
            document.body.appendChild(confirmMessage);
            
            // Supprimer le message après 2 secondes
            setTimeout(() => {
                confirmMessage.remove();
            }, 2000);
        });
    });
    
    // Initialiser l'affichage du panier
    displayCartItems();
    updateCartCount();
});

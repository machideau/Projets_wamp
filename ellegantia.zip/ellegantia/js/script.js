// Amélioration de la gestion du menu mobile
document.addEventListener('DOMContentLoaded', function() {
    // Navigation mobile
    const hamburger = document.querySelector('.hamburger');
    const navLinks = document.querySelector('.nav-links');
    const body = document.body;
    
    if (hamburger) {
        hamburger.addEventListener('click', function(e) {
            e.stopPropagation();
            navLinks.classList.toggle('active');
            
            // Empêcher le défilement du body quand le menu est ouvert
            if (navLinks.classList.contains('active')) {
                body.style.overflow = 'hidden';
            } else {
                body.style.overflow = '';
            }
        });
        
        // Fermer le menu quand on clique sur un lien
        const navLinksItems = document.querySelectorAll('.nav-links a');
        navLinksItems.forEach(link => {
            link.addEventListener('click', function() {
                navLinks.classList.remove('active');
                body.style.overflow = '';
            });
        });
        
        // Fermer le menu quand on clique en dehors
        document.addEventListener('click', function(event) {
            if (navLinks.classList.contains('active') && !event.target.closest('.nav-links') && !event.target.closest('.hamburger')) {
                navLinks.classList.remove('active');
                body.style.overflow = '';
            }
        });
    }
    
    // Gestion du scroll pour la navbar
    window.addEventListener('scroll', function() {
        const header = document.querySelector('header');
        if (window.scrollY > 50) {
            header.classList.add('scrolled');
        } else {
            header.classList.remove('scrolled');
        }
    });
    
    // Ajout de la classe scrolled au chargement si nécessaire
    if (window.scrollY > 50) {
        document.querySelector('header').classList.add('scrolled');
    }
    
    // Boutons d'authentification
    const loginButtons = document.querySelectorAll('.login-btn');
    const signupButtons = document.querySelectorAll('.signup-btn');
    
    loginButtons.forEach(button => {
        button.addEventListener('click', function() {
            window.location.href = 'login.html';
        });
    });
    
    signupButtons.forEach(button => {
        button.addEventListener('click', function() {
            window.location.href = 'signup.html';
        });
    });
    
    // Panier d'achat
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    const cartCount = document.querySelector('.cart-count');
    let cartItems = JSON.parse(localStorage.getItem('cartItems')) || [];
    
    // Mettre à jour le compteur du panier
    function updateCartCount() {
        if (cartCount) {
            cartCount.textContent = cartItems.length;
        }
    }
    
    // Initialiser le compteur
    updateCartCount();
    
    // Ajouter au panier
    addToCartButtons.forEach(button => {
        button.addEventListener('click', function() {
            const productId = button.getAttribute('data-product-id');
            const product = {
                id: productId,
                name: button.getAttribute('data-product-name'),
                price: parseFloat(button.getAttribute('data-product-price')),
                quantity: 1
            };
            
            // Vérifier si le produit existe déjà dans le panier
            const existingProductIndex = cartItems.findIndex(item => item.id === productId);
            
            if (existingProductIndex === -1) {
                cartItems.push(product);
            } else {
                cartItems[existingProductIndex].quantity += 1;
            }
            
            // Mettre à jour le localStorage
            localStorage.setItem('cartItems', JSON.stringify(cartItems));
            
            // Mettre à jour le compteur
            updateCartCount();
        });
    });
});





-- Création de la base de données
CREATE DATABASE IF NOT EXISTS ellegantia CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE ellegantia;

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    is_admin BOOLEAN DEFAULT FALSE,
    profile_picture_url VARCHAR(255),
    user_type ENUM('customer', 'admin') DEFAULT 'customer',
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Table des catégories
CREATE TABLE IF NOT EXISTS categories (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) NOT NULL UNIQUE
);

-- Table des produits
CREATE TABLE IF NOT EXISTS products (
    id INT PRIMARY KEY AUTO_INCREMENT,
    category_id INT,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255),
    stock INT NOT NULL DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

-- Table des commandes
CREATE TABLE IF NOT EXISTS orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT,
    total_amount DECIMAL(10,2) NOT NULL,
    status ENUM('pending', 'processing', 'shipped', 'delivered', 'cancelled') DEFAULT 'pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- Table des détails de commande
CREATE TABLE IF NOT EXISTS order_items (
    id INT PRIMARY KEY AUTO_INCREMENT,
    order_id INT,
    product_id INT,
    quantity INT NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- Insertion de quelques catégories
INSERT INTO categories (name, slug) VALUES
('Escarpins', 'escarpins'),
('Bottines', 'bottines'),
('Baskets', 'baskets'),
('Mocassins', 'mocassins');

-- Insertion de quelques produits
INSERT INTO products (category_id, name, description, price, image, stock) VALUES
(1, 'Escarpins Classiques', 'Escarpins élégants en cuir noir', 89.99, 'img/shoes/shoe1.jpg', 50),
(2, 'Bottines en Cuir', 'Bottines en cuir véritable', 129.99, 'img/shoes/shoe2.jpg', 30),
(3, 'Baskets Urbaines', 'Baskets confortables pour la ville', 79.99, 'img/shoes/shoe3.jpg', 100),
(4, 'Mocassins Élégants', 'Mocassins en cuir souple', 99.99, 'img/shoes/shoe4.jpg', 40);

-- Création d'un administrateur par défaut (mot de passe: admin123)
INSERT INTO users (username, email, password, is_admin) VALUES
('admin', 'admin@ellegantia.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', TRUE); 
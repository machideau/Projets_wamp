<?php
require_once 'includes/functions.php';

// Traitement des actions du panier
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'update':
                if (isset($_POST['product_id']) && isset($_POST['quantity'])) {
                    updateCartQuantity($_POST['product_id'], (int)$_POST['quantity']);
                }
                break;
            case 'remove':
                if (isset($_POST['product_id'])) {
                    removeFromCart($_POST['product_id']);
                }
                break;
            case 'clear':
                clearCart();
                break;
        }
    }
}

$cart = getCart();
$cartTotal = calculateCartTotal();
$shippingCost = $cartTotal > 0 ? 5.99 : 0;
$finalTotal = $cartTotal + $shippingCost;
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Panier - Ellegantia Shop</title>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <!-- Custom CSS -->
        <link rel="stylesheet" href="css/style.css">
        <link rel="stylesheet" href="css/panier.css">
    </head>
    <body>
        <?php include 'includes/header.php'; ?>

        <!-- PAGE TITLE -->
        <section class="page-title">
            <div class="container">
                <h1>Votre Panier</h1>
            </div>
        </section>

        <!-- CART SECTION -->
        <section class="cart-section">
            <div class="container">
                <div class="cart-grid">
                    <div class="col-lg-8">
                        <div class="cart-items-container">
                            <div class="cart-header">
                                <div class="product-header">Produit</div>
                                <div class="price-header">Prix</div>
                                <div class="quantity-header">Quantité</div>
                                <div class="total-header">Total</div>
                                <div class="actions-header"></div>
                            </div>
                            
                            <div id="cart-items">
                                <?php if (empty($cart)): ?>
                                    <div class="empty-cart-message">
                                        <p>Votre panier est vide</p>
                                        <a href="produits.php" class="btn btn-continue-shopping">Continuer vos achats</a>
                                    </div>
                                <?php else: ?>
                                    <?php foreach ($cart as $productId => $quantity): 
                                        $product = getProductById($productId);
                                        if ($product):
                                    ?>
                                        <div class="cart-item">
                                            <div class="product-info">
                                                <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                                <div class="product-details">
                                                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                                    <p class="category"><?php echo htmlspecialchars($product['category_name']); ?></p>
                                                </div>
                                            </div>
                                            <div class="price"><?php echo number_format($product['price'], 2); ?> €</div>
                                            <div class="quantity">
                                                <form method="POST" class="quantity-form">
                                                    <input type="hidden" name="action" value="update">
                                                    <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                                                    <input type="number" name="quantity" value="<?php echo $quantity; ?>" min="1" max="<?php echo $product['stock']; ?>" onchange="this.form.submit()">
                                                </form>
                                            </div>
                                            <div class="total"><?php echo number_format($product['price'] * $quantity, 2); ?> €</div>
                                            <div class="actions">
                                                <form method="POST">
                                                    <input type="hidden" name="action" value="remove">
                                                    <input type="hidden" name="product_id" value="<?php echo $productId; ?>">
                                                    <button type="submit" class="btn-remove"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endif; endforeach; ?>
                                <?php endif; ?>
                            </div>
                            
                            <div class="cart-actions">
                                <?php if (!empty($cart)): ?>
                                    <form method="POST" class="d-inline">
                                        <input type="hidden" name="action" value="clear">
                                        <button type="submit" class="btn btn-clear-cart">Vider le panier</button>
                                    </form>
                                <?php endif; ?>
                                <a href="produits.php" class="btn btn-continue-shopping">Continuer vos achats</a>
                            </div>
                        </div>
                    </div>
                    
                    <div class="col-lg-4">
                        <div class="cart-summary">
                            <h3>Récapitulatif</h3>
                            <div class="summary-item">
                                <span>Sous-total</span>
                                <span id="cart-subtotal"><?php echo number_format($cartTotal, 2); ?> €</span>
                            </div>
                            <div class="summary-item">
                                <span>Livraison</span>
                                <span id="shipping-cost"><?php echo number_format($shippingCost, 2); ?> €</span>
                            </div>
                            <div class="summary-item total">
                                <span>Total</span>
                                <span id="cart-total"><?php echo number_format($finalTotal, 2); ?> €</span>
                            </div>
                            
                            <div class="promo-code">
                                <input type="text" placeholder="Code promo" id="promo-code">
                                <button id="apply-promo">Appliquer</button>
                            </div>
                            
                            <?php if (!empty($cart)): ?>
                                <a href="checkout.php" class="btn-checkout">Procéder au paiement</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <?php include 'includes/footer.php'; ?>

        <!-- Bootstrap JS Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Custom JS -->
        <script src="js/script.js"></script>
    </body>
</html> 
document.addEventListener('DOMContentLoaded', function() {
    // Order view/edit functionality
    const viewButtons = document.querySelectorAll('.btn-view');
    const editButtons = document.querySelectorAll('.btn-edit');
    const deleteButtons = document.querySelectorAll('.btn-delete');
    
    // View order details
    viewButtons.forEach(button => {
        button.addEventListener('click', function() {
            const orderId = this.closest('tr').querySelector('td:first-child').textContent;
            // Here you would typically fetch order details and show them in a modal
            alert(`Affichage des détails de la commande ${orderId}`);
            // For a real implementation, you would open a modal with order details
        });
    });
    
    // Edit order
    editButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const orderId = row.querySelector('td:first-child').textContent;
            const status = row.querySelector('.status').textContent;
            const paymentStatus = row.querySelector('.payment-status').textContent;
            
            // Here you would typically open a modal with order edit form
            const newStatus = prompt('Modifier le statut de la commande:', status);
            if (newStatus) {
                // Update the status in the UI
                const statusElement = row.querySelector('.status');
                statusElement.textContent = newStatus;
                
                // Update the status class
                statusElement.className = 'status';
                switch(newStatus.toLowerCase()) {
                    case 'en attente':
                        statusElement.classList.add('pending');
                        break;
                    case 'en traitement':
                        statusElement.classList.add('processing');
                        break;
                    case 'expédiée':
                        statusElement.classList.add('shipped');
                        break;
                    case 'complétée':
                        statusElement.classList.add('completed');
                        break;
                    case 'annulée':
                        statusElement.classList.add('cancelled');
                        break;
                }
                
                // Here you would typically make an API call to update the order
                alert(`Statut de la commande ${orderId} mis à jour avec succès!`);
            }
        });
    });
    
    // Delete order
    deleteButtons.forEach(button => {
        button.addEventListener('click', function() {
            const row = this.closest('tr');
            const orderId = row.querySelector('td:first-child').textContent;
            
            if (confirm(`Êtes-vous sûr de vouloir supprimer la commande ${orderId}?`)) {
                row.remove();
                // Here you would typically make an API call to delete the order
                alert(`Commande ${orderId} supprimée avec succès!`);
            }
        });
    });
    
    // Date filter functionality
    const dateFromInput = document.getElementById('date-from');
    const dateToInput = document.getElementById('date-to');
    const applyFilterBtn = document.querySelector('.btn-apply-filter');
    
    if (applyFilterBtn) {
        applyFilterBtn.addEventListener('click', function() {
            const dateFrom = dateFromInput.value;
            const dateTo = dateToInput.value;
            
            if (!dateFrom || !dateTo) {
                alert('Veuillez sélectionner une période complète');
                return;
            }
            
            // Here you would typically filter orders by date range
            // For demo purposes, we'll just show a message
            alert(`Filtrage des commandes du ${dateFrom} au ${dateTo}`);
            
            // In a real implementation, you would fetch filtered orders from the server
            // or filter the existing orders in the UI
        });
    }
    
    // Status filter functionality
    const statusFilter = document.getElementById('order-status-filter');
    
    if (statusFilter) {
        statusFilter.addEventListener('change', function() {
            const status = this.value;
            const rows = document.querySelectorAll('.orders-table tbody tr');
            
            rows.forEach(row => {
                const rowStatus = row.querySelector('.status').textContent.toLowerCase();
                
                if (status === '' || rowStatus.includes(status.toLowerCase())) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });
    }
    
    // Pagination functionality
    const pageButtons = document.querySelectorAll('.page-btn:not(.prev):not(.next)');
    const prevButton = document.querySelector('.page-btn.prev');
    const nextButton = document.querySelector('.page-btn.next');
    
    if (pageButtons.length > 0) {
        pageButtons.forEach(button => {
            button.addEventListener('click', function() {
                pageButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                // Here you would typically load the corresponding page data
                console.log('Loading page ' + this.textContent);
            });
        });
    }
    
    if (prevButton) {
        prevButton.addEventListener('click', function() {
            const activeButton = document.querySelector('.page-btn.active:not(.prev):not(.next)');
            if (activeButton && activeButton.previousElementSibling && 
                !activeButton.previousElementSibling.classList.contains('prev')) {
                activeButton.previousElementSibling.click();
            }
        });
    }
    
    if (nextButton) {
        nextButton.addEventListener('click', function() {
            const activeButton = document.querySelector('.page-btn.active:not(.prev):not(.next)');
            if (activeButton && activeButton.nextElementSibling && 
                !activeButton.nextElementSibling.classList.contains('next')) {
                activeButton.nextElementSibling.click();
            }
        });
    }
});

document.addEventListener('DOMContentLoaded', function() {
    // Toggle sidebar
    const toggleSidebarBtn = document.getElementById('toggle-sidebar');
    const adminSidebar = document.querySelector('.admin-sidebar');
    const adminContent = document.querySelector('.admin-content');
    
    if (toggleSidebarBtn) {
        toggleSidebarBtn.addEventListener('click', function() {
            adminSidebar.classList.toggle('active');
            
            // Adjust content margin when sidebar is toggled
            if (adminSidebar.classList.contains('active')) {
                adminContent.style.marginLeft = 'var(--admin-sidebar-width)';
            } else {
                adminContent.style.marginLeft = '0';
            }
        });
    }
    
    // Initialize tooltips
    const tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });
    
    // Logout functionality
    const logoutBtn = document.getElementById('logout-btn');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', function(e) {
            e.preventDefault();
            
            if (confirm('Êtes-vous sûr de vouloir vous déconnecter ?')) {
                // Clear any auth tokens or session data
                localStorage.removeItem('adminLoggedIn');
                
                // Redirect to login page
                window.location.href = '../index.html';
            }
        });
    }
    
    // Responsive adjustments
    function handleResponsive() {
        if (window.innerWidth < 992) {
            adminSidebar.classList.remove('active');
            adminContent.style.marginLeft = '0';
        } else {
            adminSidebar.classList.add('active');
            adminContent.style.marginLeft = 'var(--admin-sidebar-width)';
        }
    }
    
    // Initial call
    handleResponsive();
    
    // Listen for window resize
    window.addEventListener('resize', handleResponsive);
    
    // Close sidebar when clicking outside on mobile
    document.addEventListener('click', function(e) {
        if (window.innerWidth < 992 && 
            adminSidebar.classList.contains('active') && 
            !adminSidebar.contains(e.target) && 
            e.target !== toggleSidebarBtn) {
            adminSidebar.classList.remove('active');
        }
    });
});

document.addEventListener('DOMContentLoaded', function() {
    // Select all checkboxes
    const selectAllCheckbox = document.querySelector('.select-all');
    const productCheckboxes = document.querySelectorAll('.product-select');
    const bulkActions = document.querySelector('.bulk-actions');
    const selectedCount = document.querySelector('.selected-count');
    
    // Category and status filters
    const categoryFilter = document.getElementById('category-filter');
    const statusFilter = document.getElementById('status-filter');
    
    // Buttons
    const bulkEditBtn = document.querySelector('.btn-bulk-edit');
    const bulkDeleteBtn = document.querySelector('.btn-bulk-delete');
    const addProductBtn = document.querySelector('.btn-add-product');
    
    // Handle select all checkbox
    if (selectAllCheckbox) {
        selectAllCheckbox.addEventListener('change', function() {
            const isChecked = this.checked;
            
            productCheckboxes.forEach(checkbox => {
                checkbox.checked = isChecked;
            });
            
            updateBulkActions();
        });
    }
    
    // Handle individual checkboxes
    productCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updateBulkActions);
    });
    
    function updateBulkActions() {
        const checkedCount = document.querySelectorAll('.product-select:checked').length;
        
        if (checkedCount > 0) {
            bulkActions.style.display = 'flex';
            selectedCount.textContent = checkedCount;
        } else {
            bulkActions.style.display = 'none';
        }
    }
    
    // Bulk delete functionality
    if (bulkDeleteBtn) {
        bulkDeleteBtn.addEventListener('click', function() {
            if (confirm('Êtes-vous sûr de vouloir supprimer les produits sélectionnés?')) {
                const selectedProducts = document.querySelectorAll('.product-select:checked');
                selectedProducts.forEach(checkbox => {
                    checkbox.closest('tr').remove();
                });
                
                // Here you would typically make an API call to delete the products
                alert('Produits supprimés avec succès!');
                updateBulkActions();
            }
        });
    }
    
    // Pagination functionality
    const pageButtons = document.querySelectorAll('.page-btn:not(.prev):not(.next)');
    const prevButton = document.querySelector('.page-btn.prev');
    const nextButton = document.querySelector('.page-btn.next');
    
    if (pageButtons.length > 0) {
        pageButtons.forEach(button => {
            button.addEventListener('click', function() {
                pageButtons.forEach(btn => btn.classList.remove('active'));
                this.classList.add('active');
                
                // Here you would typically load the corresponding page data
                // For demo purposes, we'll just show a message
                console.log('Loading page ' + this.textContent);
            });
        });
    }
    
    if (prevButton) {
        prevButton.addEventListener('click', function() {
            const activeButton = document.querySelector('.page-btn.active:not(.prev):not(.next)');
            if (activeButton && activeButton.previousElementSibling && 
                !activeButton.previousElementSibling.classList.contains('prev')) {
                activeButton.previousElementSibling.click();
            }
        });
    }
    
    if (nextButton) {
        nextButton.addEventListener('click', function() {
            const activeButton = document.querySelector('.page-btn.active:not(.prev):not(.next)');
            if (activeButton && activeButton.nextElementSibling && 
                !activeButton.nextElementSibling.classList.contains('next')) {
                activeButton.nextElementSibling.click();
            }
        });
    }
});


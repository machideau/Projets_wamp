<?php
require_once '../php/config.php';
require_once '../php/database.php';
require_once '../php/User.php';

// Basic authentication check - ensure user is logged in and is admin
// (This is a placeholder, real authentication should be implemented)
// session_start();
// if (!isset($_SESSION['user_id']) || $_SESSION['user_role'] !== 'admin') {
//     header('Location: ../login.php');
//     exit();
// }

$users = getAllUsers();
$message = '';
$error = '';

// Handle user actions (add, edit, delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $action = $_POST['action'];

        if ($action === 'add') {
            $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $password = $_POST['password']; // Password will be hashed in addUser
            $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

            if (addUser($username, $email, $password, $role, $status)) {
                $message = "Utilisateur ajouté avec succès.";
            } else {
                $error = "Erreur lors de l'ajout de l'utilisateur.";
            }
        } elseif ($action === 'edit') {
            $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
            $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            $email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
            $password = $_POST['password']; // Optional, only update if provided
            $role = filter_input(INPUT_POST, 'role', FILTER_SANITIZE_FULL_SPECIAL_CHARS);
            $status = filter_input(INPUT_POST, 'status', FILTER_SANITIZE_FULL_SPECIAL_CHARS);

            if ($userId && updateUser($userId, $username, $email, $role, $status, $password ?: null)) {
                $message = "Utilisateur modifié avec succès.";
            } else {
                $error = "Erreur lors de la modification de l'utilisateur.";
            }
        } elseif ($action === 'delete') {
            $userId = filter_input(INPUT_POST, 'user_id', FILTER_VALIDATE_INT);
            if ($userId && deleteUser($userId)) {
                $message = "Utilisateur supprimé avec succès.";
            }
        }

        // Redirect to clear POST data and show updated list
        header('Location: users.php?message=' . urlencode($message) . '&error=' . urlencode($error));
        exit();
    }
}

// Get messages from GET parameters after redirect
if (isset($_GET['message'])) {
    $message = htmlspecialchars($_GET['message']);
}
if (isset($_GET['error'])) {
    $error = htmlspecialchars($_GET['error']);
}

?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Utilisateurs - Ellegantia Admin</title>
    <link rel="stylesheet" href="css/admin.css">
    <link rel="stylesheet" href="css/users.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>
    <div class="admin-container">
        <aside class="sidebar">
            <div class="sidebar-header">
                <h3>Ellegantia Admin</h3>
            </div>
            <nav class="sidebar-nav">
                <ul>
                    <li><a href="index.html"><i class="fas fa-tachometer-alt"></i> Tableau de Bord</a></li>
                    <li><a href="products.php"><i class="fas fa-box"></i> Produits</a></li>
                    <li><a href="categories.php"><i class="fas fa-tags"></i> Catégories</a></li>
                    <li><a href="orders.php"><i class="fas fa-shopping-cart"></i> Commandes</a></li>
                    <li><a href="customers.php"><i class="fas fa-users"></i> Clients</a></li>
                    <li><a href="promotions.php"><i class="fas fa-ad"></i> Promotions</a></li>
                    <li><a href="users.php" class="active"><i class="fas fa-user-cog"></i> Utilisateurs</a></li>
                    <li><a href="settings.php"><i class="fas fa-cog"></i> Paramètres</a></li>
                    <li><a href="#"><i class="fas fa-sign-out-alt"></i> Déconnexion</a></li>
                </ul>
            </nav>
        </aside>
        <main class="main-content">
            <header class="main-header">
                <h1><i class="fas fa-user-cog"></i> Gestion des Utilisateurs</h1>
                <div class="header-actions">
                    <button class="add-btn" onclick="openUserModal('add')"><i class="fas fa-plus"></i> Ajouter un Utilisateur</button>
                </div>
            </header>

            <?php if ($error): ?>
                <div class="message error"><?php echo $error; ?></div>
            <?php endif; ?>
            <?php if ($message): ?>
                <div class="message success"><?php echo $message; ?></div>
            <?php endif; ?>

            <section class="users-management">
                <div class="filter-bar">
                    <input type="text" placeholder="Rechercher par nom, email..." class="search-input" id="userSearchInput">
                    <select class="filter-select" id="userRoleFilter">
                        <option value="">Tous les rôles</option>
                        <option value="admin">Administrateur</option>
                        <option value="customer">Client</option>
                    </select>
                    <button class="filter-btn" onclick="applyUserFilter()"><i class="fas fa-filter"></i> Filtrer</button>
                </div>

                <div class="users-table-container">
                    <table class="users-table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nom</th>
                                <th>Email</th>
                                <th>Rôle</th>
                                <th>Statut</th>
                                <th>Date d'inscription</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($users)): ?>
                                <?php foreach ($users as $user): ?>
                                    <tr>
                                        <td><?php echo htmlspecialchars($user['id']); ?></td>
                                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                                        <td><?php echo htmlspecialchars(ucfirst($user['role'])); ?></td>
                                        <td><?php echo htmlspecialchars(ucfirst($user['status'])); ?></td>
                                        <td><?php echo htmlspecialchars(date('Y-m-d', strtotime($user['created_at']))); ?></td>
                                        <td class="actions-column">
                                            <button class="action-btn edit-btn" title="Modifier" onclick="openUserModal('edit', <?php echo htmlspecialchars(json_encode($user)); ?>)"><i class="fas fa-edit"></i></button>
                                            <button class="action-btn delete-btn" title="Supprimer" onclick="deleteUserConfirm(<?php echo $user['id']; ?>)"><i class="fas fa-trash"></i></button>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr><td colspan="7">Aucun utilisateur trouvé.</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <!-- Pagination (can be dynamic later) -->
                <div class="pagination">
                    <button class="pagination-btn">&laquo; Précédent</button>
                    <span>Page 1 sur 1</span>
                    <button class="pagination-btn">Suivant &raquo;</button>
                </div>
            </section>

            <!-- Modals for Add/Edit User -->
            <div id="userModal" class="modal">
                <div class="modal-content">
                    <span class="close-button" onclick="closeUserModal()">&times;</span>
                    <h2 id="modalTitle">Ajouter un Utilisateur</h2>
                    <form class="user-form" id="userForm" method="POST">
                        <input type="hidden" name="action" id="userAction">
                        <input type="hidden" name="user_id" id="userId">
                        
                        <div class="form-group">
                            <label for="userName">Nom Complet</label>
                            <input type="text" id="userName" name="username" required>
                        </div>
                        <div class="form-group">
                            <label for="userEmail">Email</label>
                            <input type="email" id="userEmail" name="email" required>
                        </div>
                        <div class="form-group">
                            <label for="userRole">Rôle</label>
                            <select id="userRole" name="role">
                                <option value="customer">Client</option>
                                <option value="admin">Administrateur</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="userStatus">Statut</label>
                            <select id="userStatus" name="status">
                                <option value="active">Actif</option>
                                <option value="inactive">Inactif</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="userPassword">Mot de passe <span id="passwordHint">(requis pour l'ajout)</span></label>
                            <input type="password" id="userPassword" name="password">
                        </div>
                        <button type="submit" class="submit-btn">Sauvegarder</button>
                    </form>
                </div>
            </div>

            <!-- Delete Confirmation Modal -->
            <div id="deleteConfirmModal" class="modal">
                <div class="modal-content">
                    <span class="close-button" onclick="closeDeleteConfirmModal()">&times;</span>
                    <h2>Confirmer la Suppression</h2>
                    <p>Êtes-vous sûr de vouloir supprimer cet utilisateur ?</p>
                    <div class="modal-actions">
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="user_id" id="deleteUserId">
                            <button type="submit" class="action-btn delete-btn">Supprimer</button>
                        </form>
                        <button class="action-btn" onclick="closeDeleteConfirmModal()">Annuler</button>
                    </div>
                </div>
            </div>
        </main>
    </div>
    <script>
        const userModal = document.getElementById('userModal');
        const deleteConfirmModal = document.getElementById('deleteConfirmModal');
        const modalTitle = document.getElementById('modalTitle');
        const userAction = document.getElementById('userAction');
        const userId = document.getElementById('userId');
        const userName = document.getElementById('userName');
        const userEmail = document.getElementById('userEmail');
        const userRole = document.getElementById('userRole');
        const userStatus = document.getElementById('userStatus');
        const userPassword = document.getElementById('userPassword');
        const passwordHint = document.getElementById('passwordHint');
        const deleteUserId = document.getElementById('deleteUserId');

        function openUserModal(mode, userData = null) {
            userModal.style.display = 'block';
            userPassword.value = ''; // Clear password field

            if (mode === 'add') {
                modalTitle.textContent = 'Ajouter un Utilisateur';
                userAction.value = 'add';
                userId.value = '';
                userName.value = '';
                userEmail.value = '';
                userRole.value = 'customer';
                userStatus.value = 'active';
                userPassword.required = true;
                passwordHint.style.display = 'inline';
            } else if (mode === 'edit') {
                modalTitle.textContent = 'Modifier un Utilisateur';
                userAction.value = 'edit';
                userId.value = userData.id;
                userName.value = userData.username;
                userEmail.value = userData.email;
                userRole.value = userData.role;
                userStatus.value = userData.status;
                userPassword.required = false;
                passwordHint.style.display = 'none';
            }
        }

        function closeUserModal() {
            userModal.style.display = 'none';
            document.getElementById('userForm').reset(); // Reset form fields
        }

        function deleteUserConfirm(id) {
            deleteUserId.value = id;
            deleteConfirmModal.style.display = 'block';
        }

        function closeDeleteConfirmModal() {
            deleteConfirmModal.style.display = 'none';
        }

        // Close modals if click outside
        window.addEventListener('click', (event) => {
            if (event.target == userModal) {
                closeUserModal();
            } else if (event.target == deleteConfirmModal) {
                closeDeleteConfirmModal();
            }
        });

        // Basic filtering (client-side for now, can be server-side later)
        function applyUserFilter() {
            const searchText = document.getElementById('userSearchInput').value.toLowerCase();
            const roleFilter = document.getElementById('userRoleFilter').value.toLowerCase();
            const tableBody = document.querySelector('.users-table tbody');
            const rows = tableBody.getElementsByTagName('tr');

            for (let i = 0; i < rows.length; i++) {
                const row = rows[i];
                const nameCol = row.cells[1].textContent.toLowerCase();
                const emailCol = row.cells[2].textContent.toLowerCase();
                const roleCol = row.cells[3].textContent.toLowerCase();

                const matchesSearch = nameCol.includes(searchText) || emailCol.includes(searchText);
                const matchesRole = roleFilter === '' || roleCol === roleFilter;

                if (matchesSearch && matchesRole) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            }
        }
    </script>
</body>
</html> 
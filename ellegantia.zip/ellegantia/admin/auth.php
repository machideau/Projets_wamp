<?php
session_start();

if (!isset($_SESSION['admin_id'])) {
    header('Location: login.php');
    exit;
}

// Récupérer les informations de l'administrateur
global $pdo;
$stmt = $pdo->prepare("SELECT id, username, email FROM users WHERE id = ? AND is_admin = 1");
$stmt->execute([$_SESSION['admin_id']]);
$admin = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$admin) {
    session_destroy();
    header('Location: login.php');
    exit;
}
?> 
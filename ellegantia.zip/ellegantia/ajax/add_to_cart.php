<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = $_POST['product_id'] ?? null;
    $quantity = (int)($_POST['quantity'] ?? 1);

    if ($productId && $quantity > 0) {
        // Vérifier si le produit existe et est en stock
        $product = getProductById($productId);
        
        if ($product && $product['stock'] >= $quantity) {
            addToCart($productId, $quantity);
            echo json_encode([
                'success' => true,
                'cartCount' => array_sum(getCart()),
                'message' => 'Produit ajouté au panier'
            ]);
        } else {
            echo json_encode([
                'success' => false,
                'message' => 'Produit non disponible ou stock insuffisant'
            ]);
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'Données invalides'
        ]);
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'Méthode non autorisée'
    ]);
} 
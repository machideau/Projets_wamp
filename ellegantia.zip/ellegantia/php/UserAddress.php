<?php

require_once __DIR__ . '/database.php';

// --- User Address Methods ---

/**
 * Adds a new address for a user.
 *
 * @param array $data Associative array containing address details:
 *                    - 'user_id': ID of the user.
 *                    - 'street_address': Street address.
 *                    - 'city': City.
 *                    - 'state_province' (optional): State or province.
 *                    - 'postal_code': Postal code.
 *                    - 'country': Country.
 *                    - 'address_type' (optional): Type of address (e.g., 'shipping', 'billing', 'home').
 *                    - 'is_default' (optional): Whether this is the default address (default: 0).
 * @return int|false The ID of the newly created user address on success, false on failure.
 */
function addUserAddress($data) {
    // If setting as default, ensure other addresses for this user are not default
    if (isset($data['is_default']) && $data['is_default'] == 1) {
        db_execute('UPDATE user_addresses SET is_default = 0 WHERE user_id = :user_id', [':user_id' => $data['user_id']]);
    }

    $sql = 'INSERT INTO user_addresses (user_id, street_address, city, state_province, postal_code, country, address_type, is_default) VALUES (:user_id, :street_address, :city, :state_province, :postal_code, :country, :address_type, :is_default)';
    $params = [
        ':user_id' => $data['user_id'],
        ':street_address' => $data['street_address'],
        ':city' => $data['city'],
        ':state_province' => $data['state_province'] ?? null,
        ':postal_code' => $data['postal_code'],
        ':country' => $data['country'],
        ':address_type' => $data['address_type'] ?? 'shipping',
        ':is_default' => $data['is_default'] ?? 0
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Retrieves a user address by its ID.
 *
 * @param int $addressId The ID of the address.
 * @return object|false The user address object on success, or false if not found.
 */
function getUserAddressById($addressId) {
    $sql = 'SELECT * FROM user_addresses WHERE id = :id';
    $params = [':id' => $addressId];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves all addresses for a specific user.
 *
 * @param int $userId The ID of the user.
 * @return array An array of user address objects.
 */
function getUserAddressesByUserId($userId) {
    $sql = 'SELECT * FROM user_addresses WHERE user_id = :user_id ORDER BY is_default DESC, id DESC';
    $params = [':user_id' => $userId];
    return db_fetch_all($sql, $params);
}

/**
 * Retrieves the default address for a specific user.
 *
 * @param int $userId The ID of the user.
 * @return object|false The default address object on success, or false if not found.
 */
function getDefaultUserAddress($userId) {
    $sql = 'SELECT * FROM user_addresses WHERE user_id = :user_id AND is_default = 1';
    $params = [':user_id' => $userId];
    return db_fetch_single($sql, $params);
}

/**
 * Updates an existing user address.
 *
 * @param int $addressId The ID of the address to update.
 * @param array $data Associative array with fields to update.
 * @return bool True on success, false on failure.
 */
function updateUserAddress($addressId, $data) {
    // If setting as default, ensure other addresses for this user are not default
    if (isset($data['is_default']) && $data['is_default'] == 1 && isset($data['user_id'])) {
        db_execute('UPDATE user_addresses SET is_default = 0 WHERE user_id = :user_id AND id != :current_address_id', [':user_id' => $data['user_id'], ':current_address_id' => $addressId]);
    }

    $setParts = [];
    $params = [':id' => $addressId];

    foreach ($data as $key => $value) {
        $setParts[] = "{$key} = :{$key}";
        $params[":{$key}"] = $value;
    }

    if (empty($setParts)) {
        return false; // No data to update
    }

    $sql = 'UPDATE user_addresses SET ' . implode(', ', $setParts) . ' WHERE id = :id';
    return db_execute($sql, $params);
}

/**
 * Deletes a user address by its ID.
 *
 * @param int $addressId The ID of the address to delete.
 * @return bool True on success, false on failure.
 */
function deleteUserAddress($addressId) {
    $sql = 'DELETE FROM user_addresses WHERE id = :id';
    $params = [':id' => $addressId];
    return db_execute($sql, $params);
}

?> 
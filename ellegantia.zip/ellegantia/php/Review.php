<?php

require_once __DIR__ . '/database.php';

// --- Review Methods ---

/**
 * Adds a new product review.
 *
 * @param array $data Associative array containing review details:
 *                    - 'product_id': ID of the reviewed product.
 *                    - 'user_id': ID of the user who posted the review.
 *                    - 'rating': Rating given (1-5).
 *                    - 'comment' (optional): Text content of the review.
 *                    - 'review_date' (optional): Date of the review (default: CURRENT_TIMESTAMP).
 * @return int|false The ID of the newly created review on success, false on failure.
 */
function addReview($data) {
    $sql = 'INSERT INTO reviews (product_id, user_id, rating, comment, review_date) VALUES (:product_id, :user_id, :rating, :comment, :review_date)';
    $params = [
        ':product_id' => $data['product_id'],
        ':user_id' => $data['user_id'],
        ':rating' => $data['rating'],
        ':comment' => $data['comment'] ?? null,
        ':review_date' => $data['review_date'] ?? date('Y-m-d H:i:s')
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Retrieves a review by its ID.
 *
 * @param int $reviewId The ID of the review.
 * @return object|false The review object on success, or false if not found.
 */
function getReviewById($reviewId) {
    $sql = 'SELECT r.*, u.username, p.name as product_name 
            FROM reviews r 
            JOIN users u ON r.user_id = u.id 
            JOIN products p ON r.product_id = p.id 
            WHERE r.id = :id';
    $params = [':id' => $reviewId];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves all reviews for a specific product.
 *
 * @param int $productId The ID of the product.
 * @param int $limit Max number of reviews to return.
 * @param int $offset Offset for pagination.
 * @return array An array of review objects.
 */
function getReviewsByProductId($productId, $limit = 10, $offset = 0) {
    $sql = 'SELECT r.*, u.username 
            FROM reviews r 
            JOIN users u ON r.user_id = u.id 
            WHERE r.product_id = :product_id 
            ORDER BY r.review_date DESC LIMIT :limit OFFSET :offset';
    $params = [
        ':product_id' => $productId,
        ':limit' => $limit,
        ':offset' => $offset
    ];
    return db_fetch_all($sql, $params);
}

/**
 * Retrieves all reviews by a specific user.
 *
 * @param int $userId The ID of the user.
 * @param int $limit Max number of reviews to return.
 * @param int $offset Offset for pagination.
 * @return array An array of review objects.
 */
function getReviewsByUserId($userId, $limit = 10, $offset = 0) {
    $sql = 'SELECT r.*, p.name as product_name 
            FROM reviews r 
            JOIN products p ON r.product_id = p.id 
            WHERE r.user_id = :user_id 
            ORDER BY r.review_date DESC LIMIT :limit OFFSET :offset';
    $params = [
        ':user_id' => $userId,
        ':limit' => $limit,
        ':offset' => $offset
    ];
    return db_fetch_all($sql, $params);
}

/**
 * Updates an existing review.
 *
 * @param int $reviewId The ID of the review to update.
 * @param array $data Associative array with fields to update (e.g., 'rating', 'comment').
 * @return bool True on success, false on failure.
 */
function updateReview($reviewId, $data) {
    $setParts = [];
    $params = [':id' => $reviewId];

    foreach ($data as $key => $value) {
        $setParts[] = "{$key} = :{$key}";
        $params[":{$key}"] = $value;
    }

    if (empty($setParts)) {
        return false; // No data to update
    }

    $sql = 'UPDATE reviews SET ' . implode(', ', $setParts) . ' WHERE id = :id';
    return db_execute($sql, $params);
}

/**
 * Deletes a review by its ID.
 *
 * @param int $reviewId The ID of the review to delete.
 * @return bool True on success, false on failure.
 */
function deleteReview($reviewId) {
    $sql = 'DELETE FROM reviews WHERE id = :id';
    $params = [':id' => $reviewId];
    return db_execute($sql, $params);
}

/**
 * Calculates the average rating for a specific product.
 *
 * @param int $productId The ID of the product.
 * @return float|false The average rating, or false if no reviews.
 */
function getProductAverageRating($productId) {
    $sql = 'SELECT AVG(rating) as average_rating FROM reviews WHERE product_id = :product_id';
    $params = [':product_id' => $productId];
    $result = db_fetch_single($sql, $params);
    return $result ? (float)$result->average_rating : false;
}

?> 
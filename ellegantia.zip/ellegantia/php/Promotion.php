<?php

require_once __DIR__ . '/database.php';

// --- Promotion Methods ---

/**
 * Adds a new promotion to the database.
 *
 * @param array $data Associative array containing promotion details:
 *                    - 'code': Unique promotion code.
 *                    - 'type': Type of discount ('percentage' or 'fixed').
 *                    - 'value': Discount value.
 *                    - 'start_date': Start date of the promotion (YYYY-MM-DD).
 *                    - 'end_date': End date of the promotion (YYYY-MM-DD).
 *                    - 'min_order_amount' (optional): Minimum order amount to apply the promotion.
 *                    - 'max_uses' (optional): Maximum number of times the promotion can be used overall.
 *                    - 'max_uses_per_user' (optional): Maximum number of times a single user can use the promotion.
 *                    - 'is_active' (optional): Whether the promotion is active (default: 1).
 * @return int|false The ID of the newly created promotion on success, false on failure.
 */
function addPromotion($data) {
    $sql = 'INSERT INTO promotions (code, type, value, start_date, end_date, min_order_amount, max_uses, max_uses_per_user, is_active) VALUES (:code, :type, :value, :start_date, :end_date, :min_order_amount, :max_uses, :max_uses_per_user, :is_active)';
    $params = [
        ':code' => $data['code'],
        ':type' => $data['type'],
        ':value' => $data['value'],
        ':start_date' => $data['start_date'],
        ':end_date' => $data['end_date'],
        ':min_order_amount' => $data['min_order_amount'] ?? null,
        ':max_uses' => $data['max_uses'] ?? null,
        ':max_uses_per_user' => $data['max_uses_per_user'] ?? null,
        ':is_active' => $data['is_active'] ?? 1
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Retrieves a promotion by its ID.
 *
 * @param int $promotionId The ID of the promotion.
 * @return object|false The promotion object on success, or false if not found.
 */
function getPromotionById($promotionId) {
    $sql = 'SELECT * FROM promotions WHERE id = :id';
    $params = [':id' => $promotionId];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves a promotion by its code.
 *
 * @param string $code The code of the promotion.
 * @return object|false The promotion object on success, or false if not found.
 */
function getPromotionByCode($code) {
    $sql = 'SELECT * FROM promotions WHERE code = :code AND is_active = 1 AND start_date <= CURDATE() AND end_date >= CURDATE()';
    $params = [':code' => $code];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves all promotions, optionally filtered by active status.
 *
 * @param bool|null $isActive If true, only active promotions; if false, only inactive; if null, all.
 * @return array An array of promotion objects.
 */
function getPromotions($isActive = null) {
    $sql = 'SELECT * FROM promotions';
    $conditions = [];
    $params = [];

    if ($isActive !== null) {
        $conditions[] = 'is_active = :is_active';
        $params[':is_active'] = (int)$isActive;
    }

    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }
    $sql .= ' ORDER BY end_date DESC';

    return db_fetch_all($sql, $params);
}

/**
 * Updates an existing promotion.
 *
 * @param int $promotionId The ID of the promotion to update.
 * @param array $data Associative array with fields to update (e.g., 'value', 'end_date', 'is_active').
 * @return bool True on success, false on failure.
 */
function updatePromotion($promotionId, $data) {
    $setParts = [];
    $params = [':id' => $promotionId];

    foreach ($data as $key => $value) {
        $setParts[] = "{$key} = :{$key}";
        $params[":{$key}"] = $value;
    }

    if (empty($setParts)) {
        return false; // No data to update
    }

    $sql = 'UPDATE promotions SET ' . implode(', ', $setParts) . ' WHERE id = :id';
    return db_execute($sql, $params);
}

/**
 * Deletes a promotion by its ID.
 *
 * @param int $promotionId The ID of the promotion to delete.
 * @return bool True on success, false on failure.
 */
function deletePromotion($promotionId) {
    $sql = 'DELETE FROM promotions WHERE id = :id';
    $params = [':id' => $promotionId];
    return db_execute($sql, $params);
}

?> 
<?php

require_once __DIR__ . '/database.php';

// --- Product Methods ---

// Add Product
function addProduct($data) {
    $sql = 'INSERT INTO products (name, description, base_price, image_url, category_id, brand, status) VALUES(:name, :description, :base_price, :image_url, :category_id, :brand, :status)';
    $params = [
        ':name' => $data['name'],
        ':description' => $data['description'] ?? null,
        ':base_price' => $data['base_price'],
        ':image_url' => $data['image_url'] ?? null,
        ':category_id' => $data['category_id'] ?? null,
        ':brand' => $data['brand'] ?? null,
        ':status' => $data['status'] ?? 'available'
    ];

    if (db_execute($sql, $params)) {
        return db_last_insert_id();
    } else {
        return false;
    }
}

// Get All Products (with optional filters/pagination)
function getProducts($limit = 10, $offset = 0, $categoryId = null, $sortBy = 'created_at', $sortOrder = 'DESC') {
    $sql = 'SELECT p.*, c.name as category_name FROM products p JOIN categories c ON p.category_id = c.id';
    $conditions = [];
    $params = [];

    if ($categoryId) {
        $conditions[] = 'p.category_id = :category_id';
        $params[':category_id'] = $categoryId;
    }
    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }
    $sql .= ' ORDER BY ' . $sortBy . ' ' . $sortOrder . ' LIMIT :limit OFFSET :offset';

    $params[':limit'] = $limit;
    $params[':offset'] = $offset;

    return db_fetch_all($sql, $params);
}

// Get Single Product by ID (with variants and attributes)
function getProductById($id) {
    $sql = 
        'SELECT 
            p.*,
            c.name as category_name
        FROM 
            products p
        LEFT JOIN 
            categories c ON p.category_id = c.id
        WHERE 
            p.id = :id
        ';
    $params = [':id' => $id];
    $product = db_fetch_single($sql, $params);

    if ($product) {
        // Get product variants
        $sql_variants = 
            'SELECT 
                pv.*,
                GROUP_CONCAT(CONCAT(pa.name, ':', av.value) ORDER BY pa.name ASC SEPARATOR ';') as attributes
            FROM 
                product_variants pv
            LEFT JOIN 
                variant_attribute_values vav ON pv.id = vav.variant_id
            LEFT JOIN 
                attribute_values av ON vav.attribute_value_id = av.id
            LEFT JOIN 
                product_attributes pa ON av.attribute_id = pa.id
            WHERE 
                pv.product_id = :product_id
            GROUP BY
                pv.id
            ORDER BY
                pv.sku ASC
            ';
        $params_variants = [':product_id' => $product->id];
        $product->variants = db_fetch_all($sql_variants, $params_variants);
    }

    return $product;
}

// Update Product
function updateProduct($data) {
    $sql = 'UPDATE products SET name = :name, description = :description, base_price = :base_price, image_url = :image_url, category_id = :category_id, brand = :brand, status = :status WHERE id = :id';
    $params = [
        ':id' => $data['id'],
        ':name' => $data['name'],
        ':description' => $data['description'] ?? null,
        ':base_price' => $data['base_price'],
        ':image_url' => $data['image_url'] ?? null,
        ':category_id' => $data['category_id'] ?? null,
        ':brand' => $data['brand'] ?? null,
        ':status' => $data['status'] ?? 'available'
    ];
    return db_execute($sql, $params);
}

// Delete Product
function deleteProduct($id) {
    $sql = 'DELETE FROM products WHERE id = :id';
    $params = [':id' => $id];
    return db_execute($sql, $params);
}

// --- Product Variant Methods ---

// Add Product Variant
function addProductVariant($data) {
    db_begin_transaction();
    try {
        $sql_variant = 'INSERT INTO product_variants (product_id, sku, price_adjustment, stock_quantity, image_url, weight_g, dimensions_cm, is_active) VALUES(:product_id, :sku, :price_adjustment, :stock_quantity, :image_url, :weight_g, :dimensions_cm, :is_active)';
        $params_variant = [
            ':product_id' => $data['product_id'],
            ':sku' => $data['sku'],
            ':price_adjustment' => $data['price_adjustment'] ?? 0.00,
            ':stock_quantity' => $data['stock_quantity'] ?? 0,
            ':image_url' => $data['image_url'] ?? null,
            ':weight_g' => $data['weight_g'] ?? null,
            ':dimensions_cm' => $data['dimensions_cm'] ?? null,
            ':is_active' => $data['is_active'] ?? true
        ];
        db_execute($sql_variant, $params_variant);
        $variant_id = db_last_insert_id();

        // Link attributes to the variant
        if (isset($data['attribute_values']) && is_array($data['attribute_values'])) {
            foreach ($data['attribute_values'] as $attr_value_id) {
                $sql_link = 'INSERT INTO variant_attribute_values (variant_id, attribute_value_id) VALUES(:variant_id, :attribute_value_id)';
                $params_link = [
                    ':variant_id' => $variant_id,
                    ':attribute_value_id' => $attr_value_id
                ];
                db_execute($sql_link, $params_link);
            }
        }
        db_commit_transaction();
        return $variant_id;
    } catch (PDOException $e) {
        db_rollback_transaction();
        error_log("Error adding product variant: " . $e->getMessage());
        return false;
    }
}

// Update Product Variant
function updateProductVariant($data) {
    db_begin_transaction();
    try {
        $sql_variant = 'UPDATE product_variants SET product_id = :product_id, sku = :sku, price_adjustment = :price_adjustment, stock_quantity = :stock_quantity, image_url = :image_url, weight_g = :weight_g, dimensions_cm = :dimensions_cm, is_active = :is_active WHERE id = :id';
        $params_variant = [
            ':id' => $data['id'],
            ':product_id' => $data['product_id'],
            ':sku' => $data['sku'],
            ':price_adjustment' => $data['price_adjustment'] ?? 0.00,
            ':stock_quantity' => $data['stock_quantity'] ?? 0,
            ':image_url' => $data['image_url'] ?? null,
            ':weight_g' => $data['weight_g'] ?? null,
            ':dimensions_cm' => $data['dimensions_cm'] ?? null,
            ':is_active' => $data['is_active'] ?? true
        ];
        db_execute($sql_variant, $params_variant);

        // Update variant attributes: first delete existing, then insert new
        $sql_delete_attrs = 'DELETE FROM variant_attribute_values WHERE variant_id = :variant_id';
        $params_delete_attrs = [':variant_id' => $data['id']];
        db_execute($sql_delete_attrs, $params_delete_attrs);

        if (isset($data['attribute_values']) && is_array($data['attribute_values'])) {
            foreach ($data['attribute_values'] as $attr_value_id) {
                $sql_insert_link = 'INSERT INTO variant_attribute_values (variant_id, attribute_value_id) VALUES(:variant_id, :attribute_value_id)';
                $params_insert_link = [
                    ':variant_id' => $data['id'],
                    ':attribute_value_id' => $attr_value_id
                ];
                db_execute($sql_insert_link, $params_insert_link);
            }
        }
        db_commit_transaction();
        return true;
    } catch (PDOException $e) {
        db_rollback_transaction();
        error_log("Error updating product variant: " . $e->getMessage());
        return false;
    }
}

// Delete Product Variant
function deleteProductVariant($id) {
    $sql = 'DELETE FROM product_variants WHERE id = :id';
    $params = [':id' => $id];
    return db_execute($sql, $params);
}

// --- Product Attribute Methods ---

// Add Product Attribute (e.g., "Color", "Size")
function addProductAttribute($data) {
    $sql = 'INSERT INTO product_attributes (name, display_name) VALUES(:name, :display_name)';
    $params = [
        ':name' => $data['name'],
        ':display_name' => $data['display_name'] ?? null
    ];
    if (db_execute($sql, $params)) {
        return db_last_insert_id();
    }
    return false;
}

// Get All Product Attributes
function getProductAttributes() {
    $sql = 'SELECT * FROM product_attributes';
    return db_fetch_all($sql);
}

// Add Attribute Value (e.g., "Red" for "Color", "42" for "Size")
function addAttributeValue($data) {
    $sql = 'INSERT INTO attribute_values (attribute_id, value) VALUES(:attribute_id, :value)';
    $params = [
        ':attribute_id' => $data['attribute_id'],
        ':value' => $data['value']
    ];
    if (db_execute($sql, $params)) {
        return db_last_insert_id();
    }
    return false;
}

// Get Attribute Values for a specific Attribute ID
function getAttributeValuesByAttributeId($attribute_id) {
    $sql = 'SELECT * FROM attribute_values WHERE attribute_id = :attribute_id';
    $params = [':attribute_id' => $attribute_id];
    return db_fetch_all($sql, $params);
}

?> 
<?php

require_once __DIR__ . '/database.php';

// --- Transaction Methods ---

/**
 * Records a new transaction.
 *
 * @param array $data Associative array containing transaction details:
 *                    - 'order_id': ID of the associated order.
 *                    - 'payment_gateway_transaction_id': Transaction ID from the payment gateway.
 *                    - 'amount': Amount of the transaction.
 *                    - 'currency': Currency of the transaction (e.g., 'USD', 'EUR').
 *                    - 'transaction_type': Type of transaction (e.g., 'sale', 'refund').
 *                    - 'transaction_status': Status of the transaction (e.g., 'success', 'failed', 'pending').
 *                    - 'payment_method': Method used for payment (e.g., 'credit_card', 'paypal').
 *                    - 'transaction_date' (optional): Date of the transaction (default: CURRENT_TIMESTAMP).
 * @return int|false The ID of the newly created transaction on success, false on failure.
 */
function addTransaction($data) {
    $sql = 'INSERT INTO transactions (
        order_id, payment_gateway_transaction_id, amount, currency, 
        transaction_type, transaction_status, payment_method, transaction_date
    ) VALUES (
        :order_id, :payment_gateway_transaction_id, :amount, :currency, 
        :transaction_type, :transaction_status, :payment_method, :transaction_date
    )';
    $params = [
        ':order_id' => $data['order_id'],
        ':payment_gateway_transaction_id' => $data['payment_gateway_transaction_id'] ?? null,
        ':amount' => $data['amount'],
        ':currency' => $data['currency'],
        ':transaction_type' => $data['transaction_type'],
        ':transaction_status' => $data['transaction_status'] ?? 'pending',
        ':payment_method' => $data['payment_method'] ?? null,
        ':transaction_date' => $data['transaction_date'] ?? date('Y-m-d H:i:s')
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Retrieves a transaction by its ID.
 *
 * @param int $transactionId The ID of the transaction.
 * @return object|false The transaction object on success, or false if not found.
 */
function getTransactionById($transactionId) {
    $sql = 'SELECT t.*, o.user_id, o.total_amount as order_total 
            FROM transactions t 
            LEFT JOIN orders o ON t.order_id = o.id 
            WHERE t.id = :id';
    $params = [':id' => $transactionId];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves all transactions for a specific order.
 *
 * @param int $orderId The ID of the order.
 * @return array An array of transaction objects.
 */
function getTransactionsByOrderId($orderId) {
    $sql = 'SELECT * FROM transactions WHERE order_id = :order_id ORDER BY transaction_date DESC';
    $params = [':order_id' => $orderId];
    return db_fetch_all($sql, $params);
}

/**
 * Updates the status of a transaction.
 *
 * @param int $transactionId The ID of the transaction to update.
 * @param string $newStatus The new transaction status (e.g., 'success', 'failed', 'refunded').
 * @return bool True on success, false on failure.
 */
function updateTransactionStatus($transactionId, $newStatus) {
    $sql = 'UPDATE transactions SET transaction_status = :new_status WHERE id = :id';
    $params = [
        ':new_status' => $newStatus,
        ':id' => $transactionId
    ];
    return db_execute($sql, $params);
}

?> 
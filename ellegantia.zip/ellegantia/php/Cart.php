<?php

require_once __DIR__ . '/database.php';

// --- Cart Methods ---

/**
 * Retrieves a user's active cart, or creates one if it doesn't exist.
 *
 * @param int $userId The ID of the user.
 * @return object|false The cart object on success, or false on failure.
 */
function getOrCreateCart($userId) {
    $sql = 'SELECT * FROM carts WHERE user_id = :user_id AND status = 'active'';
    $params = [':user_id' => $userId];
    $cart = db_fetch_single($sql, $params);

    if (!$cart) {
        $sql_insert = 'INSERT INTO carts (user_id) VALUES (:user_id)';
        db_execute($sql_insert, $params);
        $cart_id = db_last_insert_id();
        if ($cart_id) {
            return getCartById($cart_id);
        } else {
            return false;
        }
    }
    return $cart;
}

/**
 * Retrieves a cart by its ID, including its items.
 *
 * @param int $cartId The ID of the cart.
 * @return object|false The cart object on success, or false if not found.
 */
function getCartById($cartId) {
    $sql_cart = 'SELECT * FROM carts WHERE id = :cart_id';
    $params_cart = [':cart_id' => $cartId];
    $cart = db_fetch_single($sql_cart, $params_cart);

    if ($cart) {
        $sql_items = 'SELECT 
                        ci.*,
                        p.name as product_name,
                        p.image_url as product_image_url,
                        pv.sku as variant_sku
                      FROM cart_items ci
                      LEFT JOIN products p ON ci.product_id = p.id
                      LEFT JOIN product_variants pv ON ci.product_variant_id = pv.id
                      WHERE ci.cart_id = :cart_id';
        $params_items = [':cart_id' => $cartId];
        $cart->items = db_fetch_all($sql_items, $params_items);
    }

    return $cart;
}

/**
 * Adds a product (or variant) to the cart, or updates its quantity if already present.
 *
 * @param int $cartId The ID of the cart.
 * @param int|null $productId The ID of the product (if no variant).
 * @param int|null $productVariantId The ID of the product variant.
 * @param int $quantity The quantity to add/set.
 * @param bool $override If true, sets quantity; if false, adds to current quantity.
 * @return int|false The ID of the cart item on success, false on failure.
 */
function addUpdateCartItem($cartId, $productId = null, $productVariantId = null, $quantity = 1, $override = false) {
    // Ensure either product_id or product_variant_id is provided
    if ($productId === null && $productVariantId === null) {
        error_log("Either product_id or product_variant_id must be provided for cart item.");
        return false;
    }

    // Check if item already exists in cart
    $sql_check = 'SELECT id, quantity FROM cart_items WHERE cart_id = :cart_id';
    $params_check = [':cart_id' => $cartId];
    if ($productId !== null) {
        $sql_check .= ' AND product_id = :product_id';
        $params_check[':product_id'] = $productId;
    } else {
        $sql_check .= ' AND product_variant_id = :product_variant_id';
        $params_check[':product_variant_id'] = $productVariantId;
    }

    $existingItem = db_fetch_single($sql_check, $params_check);

    if ($existingItem) {
        // Update existing item
        $newQuantity = $override ? $quantity : $existingItem->quantity + $quantity;
        $sql_update = 'UPDATE cart_items SET quantity = :quantity WHERE id = :id';
        $params_update = [
            ':quantity' => $newQuantity,
            ':id' => $existingItem->id
        ];
        return db_execute($sql_update, $params_update) ? $existingItem->id : false;
    } else {
        // Add new item
        $sql_insert = 'INSERT INTO cart_items (cart_id, product_id, product_variant_id, quantity) VALUES (:cart_id, :product_id, :product_variant_id, :quantity)';
        $params_insert = [
            ':cart_id' => $cartId,
            ':product_id' => $productId,
            ':product_variant_id' => $productVariantId,
            ':quantity' => $quantity
        ];
        db_execute($sql_insert, $params_insert);
        return db_last_insert_id();
    }
}

/**
 * Removes a product from the cart.
 *
 * @param int $cartId The ID of the cart.
 * @param int $cartItemId The ID of the cart item to remove.
 * @return bool True on success, false on failure.
 */
function removeCartItem($cartId, $cartItemId) {
    $sql = 'DELETE FROM cart_items WHERE id = :cart_item_id AND cart_id = :cart_id';
    $params = [
        ':cart_item_id' => $cartItemId,
        ':cart_id' => $cartId
    ];
    return db_execute($sql, $params);
}

/**
 * Clears all items from a specific cart.
 *
 * @param int $cartId The ID of the cart to clear.
 * @return bool True on success, false on failure.
 */
function clearCart($cartId) {
    $sql = 'DELETE FROM cart_items WHERE cart_id = :cart_id';
    $params = [':cart_id' => $cartId];
    return db_execute($sql, $params);
}

/**
 * Updates the status of a cart (e.g., from 'active' to 'completed').
 *
 * @param int $cartId The ID of the cart.
 * @param string $newStatus The new status (e.g., 'completed', 'abandoned').
 * @return bool True on success, false on failure.
 */
function updateCartStatus($cartId, $newStatus) {
    $sql = 'UPDATE carts SET status = :new_status WHERE id = :id';
    $params = [':new_status' => $newStatus, ':id' => $cartId];
    return db_execute($sql, $params);
}

?> 
<?php

require_once __DIR__ . '/database.php';

// --- Wishlist Methods ---

/**
 * Adds a product to a user's wishlist.
 *
 * @param int $userId The ID of the user.
 * @param int $productId The ID of the product to add.
 * @return int|false The ID of the new wishlist item on success, false on failure (e.g., if already in wishlist).
 */
function addProductToWishlist($userId, $productId) {
    // Check if the product is already in the wishlist
    $existing = db_fetch_single('SELECT id FROM wishlists WHERE user_id = :user_id AND product_id = :product_id', [':user_id' => $userId, ':product_id' => $productId]);
    if ($existing) {
        error_log("Product {$productId} already in wishlist for user {$userId}.");
        return false; // Already in wishlist
    }

    $sql = 'INSERT INTO wishlists (user_id, product_id) VALUES (:user_id, :product_id)';
    $params = [
        ':user_id' => $userId,
        ':product_id' => $productId
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Removes a product from a user's wishlist.
 *
 * @param int $userId The ID of the user.
 * @param int $productId The ID of the product to remove.
 * @return bool True on success, false on failure.
 */
function removeProductFromWishlist($userId, $productId) {
    $sql = 'DELETE FROM wishlists WHERE user_id = :user_id AND product_id = :product_id';
    $params = [
        ':user_id' => $userId,
        ':product_id' => $productId
    ];
    return db_execute($sql, $params);
}

/**
 * Retrieves all products in a user's wishlist.
 *
 * @param int $userId The ID of the user.
 * @return array An array of product objects in the wishlist.
 */
function getWishlistByUserId($userId) {
    $sql = 'SELECT w.id as wishlist_item_id, p.*, c.name as category_name
            FROM wishlists w
            JOIN products p ON w.product_id = p.id
            LEFT JOIN categories c ON p.category_id = c.id
            WHERE w.user_id = :user_id
            ORDER BY w.added_date DESC';
    $params = [':user_id' => $userId];
    return db_fetch_all($sql, $params);
}

/**
 * Checks if a product is in a user's wishlist.
 *
 * @param int $userId The ID of the user.
 * @param int $productId The ID of the product.
 * @return bool True if the product is in the wishlist, false otherwise.
 */
function isProductInWishlist($userId, $productId) {
    $sql = 'SELECT COUNT(*) FROM wishlists WHERE user_id = :user_id AND product_id = :product_id';
    $params = [':user_id' => $userId, ':product_id' => $productId];
    $result = db_fetch_single($sql, $params);
    return $result && $result->{'COUNT(*)'} > 0;
}

?> 
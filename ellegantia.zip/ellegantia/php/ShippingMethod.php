<?php

require_once __DIR__ . '/database.php';

// --- Shipping Method Methods ---

/**
 * Adds a new shipping method.
 *
 * @param array $data Associative array containing shipping method details:
 *                    - 'name': Name of the shipping method (e.g., 'Standard Shipping').
 *                    - 'cost': Cost of the shipping method.
 *                    - 'is_active' (optional): Whether the shipping method is active (default: 1).
 * @return int|false The ID of the newly created shipping method on success, false on failure.
 */
function addShippingMethod($data) {
    $sql = 'INSERT INTO shipping_methods (name, cost, is_active) VALUES (:name, :cost, :is_active)';
    $params = [
        ':name' => $data['name'],
        ':cost' => $data['cost'],
        ':is_active' => $data['is_active'] ?? 1
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Retrieves a shipping method by its ID.
 *
 * @param int $methodId The ID of the shipping method.
 * @return object|false The shipping method object on success, or false if not found.
 */
function getShippingMethodById($methodId) {
    $sql = 'SELECT * FROM shipping_methods WHERE id = :id';
    $params = [':id' => $methodId];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves all shipping methods, optionally filtered by active status.
 *
 * @param bool|null $isActive If true, only active methods; if false, only inactive; if null, all.
 * @return array An array of shipping method objects.
 */
function getShippingMethods($isActive = null) {
    $sql = 'SELECT * FROM shipping_methods';
    $conditions = [];
    $params = [];

    if ($isActive !== null) {
        $conditions[] = 'is_active = :is_active';
        $params[':is_active'] = (int)$isActive;
    }

    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }
    $sql .= ' ORDER BY name ASC';

    return db_fetch_all($sql, $params);
}

/**
 * Updates an existing shipping method.
 *
 * @param int $methodId The ID of the shipping method to update.
 * @param array $data Associative array with fields to update (e.g., 'name', 'cost', 'is_active').
 * @return bool True on success, false on failure.
 */
function updateShippingMethod($methodId, $data) {
    $setParts = [];
    $params = [':id' => $methodId];

    foreach ($data as $key => $value) {
        $setParts[] = "{$key} = :{$key}";
        $params[":{$key}"] = $value;
    }

    if (empty($setParts)) {
        return false; // No data to update
    }

    $sql = 'UPDATE shipping_methods SET ' . implode(', ', $setParts) . ' WHERE id = :id';
    return db_execute($sql, $params);
}

/**
 * Deletes a shipping method by its ID.
 *
 * @param int $methodId The ID of the shipping method to delete.
 * @return bool True on success, false on failure.
 */
function deleteShippingMethod($methodId) {
    $sql = 'DELETE FROM shipping_methods WHERE id = :id';
    $params = [':id' => $methodId];
    return db_execute($sql, $params);
}

?> 
<?php

// Database configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'root'); // Replace with your database username
define('DB_PASS', '');     // Replace with your database password
define('DB_NAME', 'ellegantia_db'); // Replace with your database name

// Other configurations
define('BASE_URL', 'http://localhost/ellegantia'); // Adjust if your project is in a subdirectory

// Error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

?> 
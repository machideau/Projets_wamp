<?php

require_once __DIR__ . '/database.php';

// Add Category
function addCategory($data) {
    $sql = 'INSERT INTO categories (name, description) VALUES(:name, :description)';
    $params = [
        ':name' => $data['name'],
        ':description' => $data['description'] ?? null
    ];
    return db_execute($sql, $params);
}

// Get all Categories
function getCategories() {
    $sql = 'SELECT * FROM categories ORDER BY name ASC';
    return db_fetch_all($sql);
}

// Get Category by ID
function getCategoryById($id) {
    $sql = 'SELECT * FROM categories WHERE id = :id';
    $params = [':id' => $id];
    return db_fetch_single($sql, $params);
}

// Update Category
function updateCategory($data) {
    $sql = 'UPDATE categories SET name = :name, description = :description WHERE id = :id';
    $params = [
        ':id' => $data['id'],
        ':name' => $data['name'],
        ':description' => $data['description'] ?? null
    ];
    return db_execute($sql, $params);
}

// Delete Category
function deleteCategory($id) {
    $sql = 'DELETE FROM categories WHERE id = :id';
    $params = [':id' => $id];
    return db_execute($sql, $params);
}

// Find category by name
function findCategoryByName($name) {
    $sql = 'SELECT * FROM categories WHERE name = :name';
    $params = [':name' => $name];
    $row = db_fetch_single($sql, $params);
    return $row ? true : false; // Return boolean if category exists
}

?> 
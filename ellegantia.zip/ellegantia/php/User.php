<?php

require_once __DIR__ . '/database.php';

// Register User
function registerUser($data) {
    $sql = 'INSERT INTO users (username, email, password_hash, full_name, street_address, city, state_province, postal_code, country, phone_number) VALUES(:username, :email, :password_hash, :full_name, :street_address, :city, :state_province, :postal_code, :country, :phone_number)';
    $params = [
        ':username' => $data['username'],
        ':email' => $data['email'],
        ':password_hash' => $data['password_hash'],
        ':full_name' => $data['full_name'] ?? null,
        ':street_address' => $data['street_address'] ?? null,
        ':city' => $data['city'] ?? null,
        ':state_province' => $data['state_province'] ?? null,
        ':postal_code' => $data['postal_code'] ?? null,
        ':country' => $data['country'] ?? null,
        ':phone_number' => $data['phone_number'] ?? null
    ];
    return db_execute($sql, $params);
}

// Find user by email
function findUserByEmail($email) {
    $sql = 'SELECT * FROM users WHERE email = :email';
    $params = [':email' => $email];
    $row = db_fetch_single($sql, $params);
    return $row; // Returns object or false
}

// Login User
function loginUser($email, $password) {
    $sql = 'SELECT * FROM users WHERE email = :email';
    $params = [':email' => $email];
    $row = db_fetch_single($sql, $params);

    if ($row) {
        $hashed_password = $row->password_hash;
        if (password_verify($password, $hashed_password)) {
            return $row;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

// Get User by ID
function getUserById($id) {
    $sql = 'SELECT * FROM users WHERE id = :id';
    $params = [':id' => $id];
    $row = db_fetch_single($sql, $params);
    return $row;
}

// Update User Profile
function updateUserProfile($data) {
    $sql = 'UPDATE users SET username = :username, full_name = :full_name, street_address = :street_address, city = :city, state_province = :state_province, postal_code = :postal_code, country = :country, phone_number = :phone_number, profile_picture_url = :profile_picture_url WHERE id = :id';
    $params = [
        ':id' => $data['id'],
        ':username' => $data['username'],
        ':full_name' => $data['full_name'] ?? null,
        ':street_address' => $data['street_address'] ?? null,
        ':city' => $data['city'] ?? null,
        ':state_province' => $data['state_province'] ?? null,
        ':postal_code' => $data['postal_code'] ?? null,
        ':country' => $data['country'] ?? null,
        ':phone_number' => $data['phone_number'] ?? null,
        ':profile_picture_url' => $data['profile_picture_url'] ?? null
    ];
    return db_execute($sql, $params);
}

// Change User Password
function changeUserPassword($id, $new_password_hash) {
    $sql = 'UPDATE users SET password_hash = :password_hash WHERE id = :id';
    $params = [
        ':id' => $id,
        ':password_hash' => $new_password_hash
    ];
    return db_execute($sql, $params);
}

// Delete User (consider soft delete in real app)
function deleteUser($id) {
    $sql = 'DELETE FROM users WHERE id = :id';
    $params = [':id' => $id];
    return db_execute($sql, $params);
}

function getAllUsers() {
    global $pdo;
    $stmt = $pdo->query("SELECT id, username, email, role, status, created_at FROM users ORDER BY created_at DESC");
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

function getUserById($userId) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id, username, email, role, status FROM users WHERE id = :id");
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    $stmt->execute();
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

function addUser($username, $email, $password, $role, $status) {
    global $pdo;
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO users (username, email, password, role, status) VALUES (:username, :email, :password, :role, :status)");
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':password', $hashed_password);
    $stmt->bindParam(':role', $role);
    $stmt->bindParam(':status', $status);
    return $stmt->execute();
}

function updateUser($userId, $username, $email, $role, $status, $password = null) {
    global $pdo;
    $sql = "UPDATE users SET username = :username, email = :email, role = :role, status = :status";
    if ($password) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = :password";
    }
    $sql .= " WHERE id = :id";

    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':username', $username);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':role', $role);
    $stmt->bindParam(':status', $status);
    if ($password) {
        $stmt->bindParam(':password', $hashed_password);
    }
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    return $stmt->execute();
}

function deleteUser($userId) {
    global $pdo;
    $stmt = $pdo->prepare("DELETE FROM users WHERE id = :id");
    $stmt->bindParam(':id', $userId, PDO::PARAM_INT);
    return $stmt->execute();
}

?> 
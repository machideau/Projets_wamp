<?php

require_once __DIR__ . '/database.php';

// --- Setting Methods ---

/**
 * Retrieves a setting value by its name.
 *
 * @param string $settingName The name of the setting.
 * @return string|false The setting value on success, or false if not found.
 */
function getSetting($settingName) {
    $sql = 'SELECT setting_value FROM settings WHERE setting_name = :setting_name';
    $params = [':setting_name' => $settingName];
    $result = db_fetch_single($sql, $params);
    return $result ? $result->setting_value : false;
}

/**
 * Updates a setting value. If the setting does not exist, it creates it.
 *
 * @param string $settingName The name of the setting.
 * @param string $settingValue The new value for the setting.
 * @return bool True on success, false on failure.
 */
function updateSetting($settingName, $settingValue) {
    // Try to update first
    $sql_update = 'UPDATE settings SET setting_value = :setting_value WHERE setting_name = :setting_name';
    $params_update = [':setting_value' => $settingValue, ':setting_name' => $settingName];
    if (db_execute($sql_update, $params_update) && db_rows_affected() > 0) {
        return true;
    }

    // If no rows were affected, the setting doesn't exist, so insert it
    $sql_insert = 'INSERT INTO settings (setting_name, setting_value) VALUES (:setting_name, :setting_value)';
    $params_insert = [':setting_name' => $settingName, ':setting_value' => $settingValue];
    return db_execute($sql_insert, $params_insert);
}

/**
 * Retrieves all settings.
 *
 * @return array An associative array of all settings (name => value).
 */
function getAllSettings() {
    $sql = 'SELECT setting_name, setting_value FROM settings';
    $results = db_fetch_all($sql);
    $settings = [];
    foreach ($results as $row) {
        $settings[$row->setting_name] = $row->setting_value;
    }
    return $settings;
}

/**
 * Deletes a setting by its name.
 *
 * @param string $settingName The name of the setting to delete.
 * @return bool True on success, false on failure.
 */
function deleteSetting($settingName) {
    $sql = 'DELETE FROM settings WHERE setting_name = :setting_name';
    $params = [':setting_name' => $settingName];
    return db_execute($sql, $params);
}

?> 
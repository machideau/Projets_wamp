<?php

require_once __DIR__ . '/database.php';

// --- Notification Methods ---

/**
 * Adds a new notification.
 *
 * @param array $data Associative array containing notification details:
 *                    - 'user_id' (optional): ID of the user to notify (if null, it's a general notification).
 *                    - 'type': Type of notification (e.g., 'order_status', 'promotion', 'system').
 *                    - 'message': The content of the notification.
 *                    - 'is_read' (optional): Whether the notification has been read (default: 0).
 *                    - 'created_at' (optional): Timestamp of creation (default: CURRENT_TIMESTAMP).
 * @return int|false The ID of the newly created notification on success, false on failure.
 */
function addNotification($data) {
    $sql = 'INSERT INTO notifications (user_id, type, message, is_read, created_at) VALUES (:user_id, :type, :message, :is_read, :created_at)';
    $params = [
        ':user_id' => $data['user_id'] ?? null,
        ':type' => $data['type'],
        ':message' => $data['message'],
        ':is_read' => $data['is_read'] ?? 0,
        ':created_at' => $data['created_at'] ?? date('Y-m-d H:i:s')
    ];
    db_execute($sql, $params);
    return db_last_insert_id();
}

/**
 * Retrieves a notification by its ID.
 *
 * @param int $notificationId The ID of the notification.
 * @return object|false The notification object on success, or false if not found.
 */
function getNotificationById($notificationId) {
    $sql = 'SELECT * FROM notifications WHERE id = :id';
    $params = [':id' => $notificationId];
    return db_fetch_single($sql, $params);
}

/**
 * Retrieves notifications for a specific user or general notifications.
 *
 * @param int|null $userId The ID of the user (null for general notifications).
 * @param bool|null $isRead If true, only read notifications; if false, only unread; if null, all.
 * @param int $limit Max number of notifications to return.
 * @param int $offset Offset for pagination.
 * @return array An array of notification objects.
 */
function getNotifications($userId = null, $isRead = null, $limit = 20, $offset = 0) {
    $sql = 'SELECT * FROM notifications';
    $conditions = [];
    $params = [];

    if ($userId !== null) {
        $conditions[] = 'user_id = :user_id';
        $params[':user_id'] = $userId;
    } else {
        // If no user ID, retrieve general notifications (user_id IS NULL)
        $conditions[] = 'user_id IS NULL';
    }

    if ($isRead !== null) {
        $conditions[] = 'is_read = :is_read';
        $params[':is_read'] = (int)$isRead;
    }

    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }
    $sql .= ' ORDER BY created_at DESC LIMIT :limit OFFSET :offset';
    $params[':limit'] = $limit;
    $params[':offset'] = $offset;

    return db_fetch_all($sql, $params);
}

/**
 * Marks a notification as read.
 *
 * @param int $notificationId The ID of the notification to mark as read.
 * @return bool True on success, false on failure.
 */
function markNotificationAsRead($notificationId) {
    $sql = 'UPDATE notifications SET is_read = 1 WHERE id = :id';
    $params = [':id' => $notificationId];
    return db_execute($sql, $params);
}

/**
 * Deletes a notification by its ID.
 *
 * @param int $notificationId The ID of the notification to delete.
 * @return bool True on success, false on failure.
 */
function deleteNotification($notificationId) {
    $sql = 'DELETE FROM notifications WHERE id = :id';
    $params = [':id' => $notificationId];
    return db_execute($sql, $params);
}

/**
 * Deletes all notifications for a specific user.
 *
 * @param int $userId The ID of the user.
 * @return bool True on success, false on failure.
 */
function deleteAllUserNotifications($userId) {
    $sql = 'DELETE FROM notifications WHERE user_id = :user_id';
    $params = [':user_id' => $userId];
    return db_execute($sql, $params);
}

?> 
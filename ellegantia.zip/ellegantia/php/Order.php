<?php

require_once __DIR__ . '/database.php';

// --- Order Methods ---

/**
 * Adds a new order to the database.
 * Manages transaction for order and order items insertion.
 *
 * @param array $data Associative array containing order details:
 *                    - 'user_id': ID of the user placing the order.
 *                    - 'total_amount': Total amount of the order.
 *                    - 'shipping_street_address', 'shipping_city', 'shipping_state_province', 'shipping_postal_code', 'shipping_country': Shipping address details.
 *                    - 'shipping_method_id': ID of the chosen shipping method.
 *                    - 'shipping_cost_at_order': Cost of shipping at the time of order.
 *                    - 'discount_amount': Total discount applied to the order.
 *                    - 'order_status': Initial status of the order (default: 'pending').
 *                    - 'payment_status': Initial payment status (default: 'pending').
 *                    - 'payment_transaction_id': Transaction ID from payment gateway.
 *                    - 'tracking_number': Tracking number for the shipment.
 *                    - 'items': An array of order items, each being an associative array with:
 *                               - 'product_id' (optional): ID of the product if no variant.
 *                               - 'product_variant_id' (optional): ID of the product variant.
 *                               - 'quantity': Quantity of the item.
 *                               - 'price_at_purchase': Price of the item at purchase time.
 * @return int|false The ID of the newly created order on success, false on failure.
 */
function addOrder($data) {
    db_begin_transaction();
    try {
        $sql_order = 'INSERT INTO orders (
            user_id, total_amount, shipping_street_address, shipping_city, 
            shipping_state_province, shipping_postal_code, shipping_country, 
            shipping_method_id, shipping_cost_at_order, discount_amount, 
            order_status, payment_status, payment_transaction_id, tracking_number
        ) VALUES (
            :user_id, :total_amount, :shipping_street_address, :shipping_city, 
            :shipping_state_province, :shipping_postal_code, :shipping_country, 
            :shipping_method_id, :shipping_cost_at_order, :discount_amount, 
            :order_status, :payment_status, :payment_transaction_id, :tracking_number
        )';
        $params_order = [
            ':user_id' => $data['user_id'],
            ':total_amount' => $data['total_amount'],
            ':shipping_street_address' => $data['shipping_street_address'],
            ':shipping_city' => $data['shipping_city'],
            ':shipping_state_province' => $data['shipping_state_province'] ?? null,
            ':shipping_postal_code' => $data['shipping_postal_code'],
            ':shipping_country' => $data['shipping_country'],
            ':shipping_method_id' => $data['shipping_method_id'] ?? null,
            ':shipping_cost_at_order' => $data['shipping_cost_at_order'] ?? 0.00,
            ':discount_amount' => $data['discount_amount'] ?? 0.00,
            ':order_status' => $data['order_status'] ?? 'pending',
            ':payment_status' => $data['payment_status'] ?? 'pending',
            ':payment_transaction_id' => $data['payment_transaction_id'] ?? null,
            ':tracking_number' => $data['tracking_number'] ?? null
        ];

        db_execute($sql_order, $params_order);
        $order_id = db_last_insert_id();

        if (!$order_id) {
            throw new Exception("Could not retrieve last insert ID for order.");
        }

        // Insert order items
        foreach ($data['items'] as $item) {
            $sql_item = 'INSERT INTO order_items (order_id, product_id, product_variant_id, quantity, price_at_purchase) VALUES(:order_id, :product_id, :product_variant_id, :quantity, :price_at_purchase)';
            $params_item = [
                ':order_id' => $order_id,
                ':product_id' => $item['product_id'] ?? null,
                ':product_variant_id' => $item['product_variant_id'] ?? null,
                ':quantity' => $item['quantity'],
                ':price_at_purchase' => $item['price_at_purchase']
            ];
            db_execute($sql_item, $params_item);
        }

        db_commit_transaction();
        return $order_id;
    } catch (Exception $e) {
        db_rollback_transaction();
        error_log("Error adding order: " . $e->getMessage());
        return false;
    }
}

/**
 * Retrieves all orders with associated user and shipping method details.
 *
 * @param int $limit Max number of orders to return.
 * @param int $offset Offset for pagination.
 * @param string|null $status Filter by order status.
 * @param int|null $userId Filter by user ID.
 * @return array An array of order objects.
 */
function getOrders($limit = 20, $offset = 0, $status = null, $userId = null) {
    $sql = 'SELECT o.*, u.username, sm.name as shipping_method_name 
            FROM orders o 
            JOIN users u ON o.user_id = u.id
            LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id';
    $conditions = [];
    $params = [];

    if ($status) {
        $conditions[] = 'o.order_status = :status';
        $params[':status'] = $status;
    }
    if ($userId) {
        $conditions[] = 'o.user_id = :user_id';
        $params[':user_id'] = $userId;
    }

    if (!empty($conditions)) {
        $sql .= ' WHERE ' . implode(' AND ', $conditions);
    }

    $sql .= ' ORDER BY o.order_date DESC LIMIT :limit OFFSET :offset';
    $params[':limit'] = $limit;
    $params[':offset'] = $offset;

    return db_fetch_all($sql, $params);
}

/**
 * Retrieves a single order by its ID, including its items.
 *
 * @param int $orderId The ID of the order to retrieve.
 * @return object|false The order object on success, or false if not found.
 */
function getOrderById($orderId) {
    $sql_order = 'SELECT o.*, u.username, sm.name as shipping_method_name 
                  FROM orders o 
                  JOIN users u ON o.user_id = u.id
                  LEFT JOIN shipping_methods sm ON o.shipping_method_id = sm.id
                  WHERE o.id = :order_id';
    $params_order = [':order_id' => $orderId];
    $order = db_fetch_single($sql_order, $params_order);

    if ($order) {
        $sql_items = 'SELECT 
                        oi.*,
                        p.name as product_name,
                        p.image_url as product_image_url,
                        pv.sku as variant_sku
                      FROM order_items oi
                      LEFT JOIN products p ON oi.product_id = p.id
                      LEFT JOIN product_variants pv ON oi.product_variant_id = pv.id
                      WHERE oi.order_id = :order_id';
        $params_items = [':order_id' => $orderId];
        $order->items = db_fetch_all($sql_items, $params_items);
    }

    return $order;
}

/**
 * Updates the status of an order.
 *
 * @param int $orderId The ID of the order to update.
 * @param string $newStatus The new order status (e.g., 'processing', 'shipped', 'delivered', 'cancelled').
 * @return bool True on success, false on failure.
 */
function updateOrderStatus($orderId, $newStatus) {
    $sql = 'UPDATE orders SET order_status = :new_status WHERE id = :id';
    $params = [
        ':new_status' => $newStatus,
        ':id' => $orderId
    ];
    return db_execute($sql, $params);
}

/**
 * Updates the payment status of an order.
 *
 * @param int $orderId The ID of the order to update.
 * @param string $newPaymentStatus The new payment status (e.g., 'paid', 'refunded', 'failed').
 * @param string|null $transactionId (Optional) The transaction ID if applicable.
 * @return bool True on success, false on failure.
 */
function updateOrderPaymentStatus($orderId, $newPaymentStatus, $transactionId = null) {
    $sql = 'UPDATE orders SET payment_status = :new_payment_status';
    $params = [':new_payment_status' => $newPaymentStatus, ':id' => $orderId];

    if ($transactionId !== null) {
        $sql .= ', payment_transaction_id = :transaction_id';
        $params[':transaction_id'] = $transactionId;
    }
    $sql .= ' WHERE id = :id';
    
    return db_execute($sql, $params);
}

/**
 * Deletes an order.
 *
 * @param int $orderId The ID of the order to delete.
 * @return bool True on success, false on failure.
 */
function deleteOrder($orderId) {
    // Due to ON DELETE CASCADE, order_items will be deleted automatically
    $sql = 'DELETE FROM orders WHERE id = :id';
    $params = [':id' => $orderId];
    return db_execute($sql, $params);
}

?> 
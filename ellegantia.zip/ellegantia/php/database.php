<?php

require_once __DIR__ . '/config.php';

// Global PDO connection variable
global $pdo_dbh;
global $pdo_stmt;
global $pdo_error;

/**
 * Establishes a PDO database connection.
 * Initializes the global $pdo_dbh if not already set.
 *
 * @return PDO|false The PDO database connection object on success, or false on failure.
 */
function db_connect() {
    global $pdo_dbh;
    global $pdo_error;

    if ($pdo_dbh) {
        return $pdo_dbh; // Return existing connection if already established
    }

    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME;
    $options = [
        PDO::ATTR_PERSISTENT => true, // Persistent connection
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, // Throw exceptions on errors
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8" // Set character set
    ];

    try {
        $pdo_dbh = new PDO($dsn, DB_USER, DB_PASS, $options);
        return $pdo_dbh;
    } catch (PDOException $e) {
        $pdo_error = $e->getMessage();
        echo $pdo_error;
        // Log the error in a real application
        error_log("Database connection error: " . $pdo_error);
        die("Database connection failed. Please try again later.");
    }
}

/**
 * Prepares a SQL query and binds parameters.
 *
 * @param string $sql The SQL query string.
 * @param array $params An associative array of parameters to bind.
 * @return PDOStatement|false The PDOStatement object on success, or false on failure.
 */
function db_prepare_execute($sql, $params = []) {
    global $pdo_dbh;
    global $pdo_stmt;
    global $pdo_error;

    if (!$pdo_dbh) {
        db_connect(); // Ensure connection is established
    }

    try {
        $pdo_stmt = $pdo_dbh->prepare($sql);
        foreach ($params as $param => $value) {
            $type = null;
            if (is_int($value)) {
                $type = PDO::PARAM_INT;
            } elseif (is_bool($value)) {
                $type = PDO::PARAM_BOOL;
            } elseif (is_null($value)) {
                $type = PDO::PARAM_NULL;
            } else {
                $type = PDO::PARAM_STR;
            }
            $pdo_stmt->bindValue($param, $value, $type);
        }
        $pdo_stmt->execute();
        return $pdo_stmt;
    } catch (PDOException $e) {
        $pdo_error = $e->getMessage();
        error_log("Query execution error: " . $pdo_error . " SQL: " . $sql);
        return false;
    }
}

/**
 * Executes an SQL query (INSERT, UPDATE, DELETE).
 *
 * @param string $sql The SQL query string.
 * @param array $params An associative array of parameters to bind.
 * @return bool True on success, false on failure.
 */
function db_execute($sql, $params = []) {
    $stmt = db_prepare_execute($sql, $params);
    return $stmt !== false;
}

/**
 * Fetches all rows from a SELECT query.
 *
 * @param string $sql The SQL SELECT query string.
 * @param array $params An associative array of parameters to bind.
 * @return array An array of objects, or an empty array if no results.
 */
function db_fetch_all($sql, $params = []) {
    $stmt = db_prepare_execute($sql, $params);
    if ($stmt) {
        return $stmt->fetchAll(PDO::FETCH_OBJ);
    }
    return [];
}

/**
 * Fetches a single row from a SELECT query.
 *
 * @param string $sql The SQL SELECT query string.
 * @param array $params An associative array of parameters to bind.
 * @return object|false A single object on success, or false if no record found.
 */
function db_fetch_single($sql, $params = []) {
    $stmt = db_prepare_execute($sql, $params);
    if ($stmt) {
        return $stmt->fetch(PDO::FETCH_OBJ);
    }
    return false;
}

/**
 * Returns the number of rows affected by the last INSERT, UPDATE, or DELETE statement.
 *
 * @return int The number of affected rows.
 */
function db_row_count() {
    global $pdo_stmt;
    if ($pdo_stmt) {
        return $pdo_stmt->rowCount();
    }
    return 0;
}

/**
 * Returns the ID of the last inserted row or sequence value.
 *
 * @return string|false The ID of the last inserted row on success, or false on failure.
 */
function db_last_insert_id() {
    global $pdo_dbh;
    if ($pdo_dbh) {
        return $pdo_dbh->lastInsertId();
    }
    return false;
}

/**
 * Begins a transaction.
 *
 * @return bool True on success, false on failure.
 */
function db_begin_transaction() {
    global $pdo_dbh;
    if (!$pdo_dbh) {
        db_connect();
    }
    if ($pdo_dbh) {
        return $pdo_dbh->beginTransaction();
    }
    return false;
}

/**
 * Commits a transaction.
 *
 * @return bool True on success, false on failure.
 */
function db_commit_transaction() {
    global $pdo_dbh;
    if ($pdo_dbh) {
        return $pdo_dbh->commit();
    }
    return false;
}

/**
 * Rolls back a transaction.
 *
 * @return bool True on success, false on failure.
 */
function db_rollback_transaction() {
    global $pdo_dbh;
    if ($pdo_dbh) {
        return $pdo_dbh->rollBack();
    }
    return false;
}

// Ensure database connection is established when this file is included
db_connect();

?> 
<?php
require_once 'php/config.php';
require_once 'php/database.php';
require_once 'php/PasswordReset.php';

$error = '';
$success = '';
$showResetForm = false;
$email = '';

// Check if we have a token in the URL
if (isset($_GET['token'])) {
    $token = $_GET['token'];
    $tokenData = verifyPasswordResetToken($token);
    
    if ($tokenData) {
        $showResetForm = true;
    } else {
        $error = "Le lien de réinitialisation est invalide ou a expiré.";
    }
}

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['email'])) {
        // Request password reset
        $email = filter_var($_POST['email'], FILTER_SANITIZE_EMAIL);
        if (initiatePasswordReset($email)) {
            $success = "Si un compte existe avec cette adresse email, vous recevrez un lien de réinitialisation.";
        } else {
            $error = "Une erreur s'est produite. Veuillez réessayer.";
        }
    } elseif (isset($_POST['token']) && isset($_POST['password'])) {
        // Reset password
        $token = $_POST['token'];
        $password = $_POST['password'];
        $confirmPassword = $_POST['confirm_password'];

        if ($password !== $confirmPassword) {
            $error = "Les mots de passe ne correspondent pas.";
        } elseif (strlen($password) < 8) {
            $error = "Le mot de passe doit contenir au moins 8 caractères.";
        } else {
            if (resetPasswordWithToken($token, $password)) {
                $success = "Votre mot de passe a été réinitialisé avec succès. Vous pouvez maintenant vous connecter.";
                $showResetForm = false;
            } else {
                $error = "Une erreur s'est produite lors de la réinitialisation du mot de passe.";
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Réinitialisation du mot de passe - Ellegantia</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .reset-container {
            max-width: 400px;
            margin: 50px auto;
            padding: 20px;
            background: #fff;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .reset-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }
        .reset-form input {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        .reset-form button {
            padding: 12px;
            background: var(--primary-color);
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .reset-form button:hover {
            background: var(--primary-color-dark);
        }
        .message {
            padding: 10px;
            margin-bottom: 15px;
            border-radius: 4px;
        }
        .error {
            background: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        .success {
            background: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }
    </style>
</head>
<body>
    <div class="reset-container">
        <h1>Réinitialisation du mot de passe</h1>
        
        <?php if ($error): ?>
            <div class="message error"><?php echo htmlspecialchars($error); ?></div>
        <?php endif; ?>
        
        <?php if ($success): ?>
            <div class="message success"><?php echo htmlspecialchars($success); ?></div>
        <?php endif; ?>

        <?php if ($showResetForm): ?>
            <!-- Form to reset password -->
            <form class="reset-form" method="POST">
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                <div>
                    <label for="password">Nouveau mot de passe</label>
                    <input type="password" id="password" name="password" required minlength="8">
                </div>
                <div>
                    <label for="confirm_password">Confirmer le mot de passe</label>
                    <input type="password" id="confirm_password" name="confirm_password" required minlength="8">
                </div>
                <button type="submit">Réinitialiser le mot de passe</button>
            </form>
        <?php else: ?>
            <!-- Form to request password reset -->
            <form class="reset-form" method="POST">
                <div>
                    <label for="email">Adresse email</label>
                    <input type="email" id="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
                </div>
                <button type="submit">Envoyer le lien de réinitialisation</button>
            </form>
        <?php endif; ?>

        <p style="text-align: center; margin-top: 20px;">
            <a href="login.php">Retour à la connexion</a>
        </p>
    </div>
</body>
</html> 
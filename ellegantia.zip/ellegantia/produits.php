<?php
require_once 'includes/functions.php';

// Récupérer la catégorie sélectionnée
$categorySlug = $_GET['category'] ?? null;
$categoryId = null;

if ($categorySlug) {
    global $pdo;
    $stmt = $pdo->prepare("SELECT id FROM categories WHERE slug = ?");
    $stmt->execute([$categorySlug]);
    $category = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($category) {
        $categoryId = $category['id'];
    }
}

// Récupérer les produits
$products = $categoryId ? getProductsByCategory($categoryId) : getAllProducts();
$categories = getAllCategories();
?>
<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Produits - Ellegantia Shop</title>
        <!-- Bootstrap CSS -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet">
        <!-- Font Awesome -->
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
        <!-- Custom CSS -->
        <link rel="stylesheet" href="css/style.css">
    </head>
    <body>
        <?php include 'includes/header.php'; ?>

        <!-- PAGE TITLE -->
        <section class="page-title">
            <div class="container">
                <h1>Nos Produits</h1>
            </div>
        </section>

        <!-- PRODUCTS SECTION -->
        <section class="products-section">
            <div class="container">
                <div class="row">
                    <!-- FILTERS SIDEBAR -->
                    <div class="col-lg-3">
                        <div class="filters-sidebar">
                            <h3>Catégories</h3>
                            <ul class="category-list">
                                <li class="<?php echo !$categorySlug ? 'active' : ''; ?>">
                                    <a href="produits.php">Tous les produits</a>
                                </li>
                                <?php foreach ($categories as $category): ?>
                                    <li class="<?php echo $categorySlug === $category['slug'] ? 'active' : ''; ?>">
                                        <a href="produits.php?category=<?php echo htmlspecialchars($category['slug']); ?>">
                                            <?php echo htmlspecialchars($category['name']); ?>
                                        </a>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </div>
                    </div>

                    <!-- PRODUCTS GRID -->
                    <div class="col-lg-9">
                        <div class="products-grid">
                            <?php if (empty($products)): ?>
                                <div class="no-products">
                                    <p>Aucun produit trouvé dans cette catégorie.</p>
                                </div>
                            <?php else: ?>
                                <div class="row">
                                    <?php foreach ($products as $product): ?>
                                        <div class="col-md-4 col-sm-6">
                                            <div class="product-card">
                                                <div class="product-image">
                                                    <img src="<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                                                    <?php if ($product['stock'] > 0): ?>
                                                        <div class="product-tag">En stock</div>
                                                    <?php else: ?>
                                                        <div class="product-tag out-of-stock">Rupture de stock</div>
                                                    <?php endif; ?>
                                                    <div class="product-actions">
                                                        <button class="quick-view" data-product-id="<?php echo $product['id']; ?>">
                                                            <i class="fa fa-eye"></i>
                                                        </button>
                                                        <button class="wishlist">
                                                            <i class="fa fa-heart"></i>
                                                        </button>
                                                    </div>
                                                </div>
                                                <div class="product-info">
                                                    <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                                                    <p class="category"><?php echo htmlspecialchars($product['category_name']); ?></p>
                                                    <div class="product-price"><?php echo number_format($product['price'], 2); ?> €</div>
                                                    <?php if ($product['stock'] > 0): ?>
                                                        <button class="btn add-to-cart" 
                                                                data-product-id="<?php echo $product['id']; ?>"
                                                                data-product-name="<?php echo htmlspecialchars($product['name']); ?>"
                                                                data-product-price="<?php echo $product['price']; ?>">
                                                            Ajouter au panier
                                                        </button>
                                                    <?php else: ?>
                                                        <button class="btn btn-disabled" disabled>Rupture de stock</button>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; ?>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>

        <!-- QUICK VIEW MODAL -->
        <div class="modal fade" id="quickViewModal" tabindex="-1" aria-hidden="true">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">Aperçu rapide</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <!-- Le contenu sera chargé dynamiquement via JavaScript -->
                    </div>
                </div>
            </div>
        </div>

        <?php include 'includes/footer.php'; ?>

        <!-- Bootstrap JS Bundle with Popper -->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Custom JS -->
        <script src="js/script.js"></script>
        <script>
            // Gestion du panier
            document.querySelectorAll('.add-to-cart').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.dataset.productId;
                    const productName = this.dataset.productName;
                    const productPrice = this.dataset.productPrice;

                    // Envoyer une requête AJAX pour ajouter au panier
                    fetch('ajax/add_to_cart.php', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `product_id=${productId}&quantity=1`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            // Mettre à jour le compteur du panier
                            const cartCount = document.querySelector('.cart-count');
                            if (cartCount) {
                                cartCount.textContent = data.cartCount;
                            }
                            // Afficher un message de succès
                            alert('Produit ajouté au panier !');
                        } else {
                            alert('Erreur lors de l\'ajout au panier.');
                        }
                    })
                    .catch(error => {
                        console.error('Erreur:', error);
                        alert('Erreur lors de l\'ajout au panier.');
                    });
                });
            });

            // Gestion de l'aperçu rapide
            document.querySelectorAll('.quick-view').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.dataset.productId;
                    const modal = new bootstrap.Modal(document.getElementById('quickViewModal'));
                    
                    // Charger les détails du produit
                    fetch(`ajax/get_product.php?id=${productId}`)
                        .then(response => response.json())
                        .then(data => {
                            if (data.success) {
                                const modalBody = document.querySelector('#quickViewModal .modal-body');
                                modalBody.innerHTML = `
                                    <div class="row">
                                        <div class="col-md-6">
                                            <img src="${data.product.image}" alt="${data.product.name}" class="img-fluid">
                                        </div>
                                        <div class="col-md-6">
                                            <h3>${data.product.name}</h3>
                                            <p class="category">${data.product.category_name}</p>
                                            <div class="price">${data.product.price} €</div>
                                            <p class="description">${data.product.description}</p>
                                            <button class="btn btn-primary add-to-cart" 
                                                    data-product-id="${data.product.id}"
                                                    data-product-name="${data.product.name}"
                                                    data-product-price="${data.product.price}">
                                                Ajouter au panier
                                            </button>
                                        </div>
                                    </div>
                                `;
                                modal.show();
                            }
                        })
                        .catch(error => {
                            console.error('Erreur:', error);
                            alert('Erreur lors du chargement des détails du produit.');
                        });
                });
            });
        </script>
    </body>
</html> 
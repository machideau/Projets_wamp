<hr>
<footer>
    <p>&copy; 2025 Mon Blog PHP</p>
</footer>
</div>
</body>
</html>

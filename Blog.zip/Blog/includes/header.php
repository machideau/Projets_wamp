<?php 
require_once 'auth.php';
if (session_status() === PHP_SESSION_NONE) session_start(); 
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Blog PHP</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container">
        <header>
            <h1><a href="index.php">Mon Blog</a></h1>
            <nav>
                <?php if (est_connecte()): ?>
                    Bonjour, <?= htmlspecialchars($_SESSION['utilisateur']['nom_utilisateur']) ?> |
                    <a href="logout.php">Déconnexion</a>
                    <?php if (est_admin()): ?> |
                        <a href="admin.php">Admin</a>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="login.php">Connexion</a> |
                    <a href="register.php">Inscription</a>
                <?php endif; ?>
            </nav>
        </header>
        <hr>
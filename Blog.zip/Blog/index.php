<?php
require_once 'includes/db.php';
require_once 'includes/header.php';

$sql = "SELECT a.id, a.titre, a.date_publication, u.nom_utilisateur
        FROM articles a
        LEFT JOIN utilisateurs u ON a.auteur_id = u.id
        ORDER BY a.date_publication DESC";
$result = $conn->query($sql);
?>

<h2>Articles récents</h2>
<?php if ($result && $result->num_rows > 0): ?>
    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="article">
            <h3><a href="article.php?id=<?= $row['id'] ?>"><?= $row['titre'] ?></a></h3>
            <p>Publié par <?= $row['nom_utilisateur'] ?> le <?= $row['date_publication'] ?></p>
        </div>
    <?php endwhile; ?>
<?php else: ?>
    <p>Aucun article trouvé.</p>
<?php endif; ?>

<?php require_once 'includes/footer.php'; ?>